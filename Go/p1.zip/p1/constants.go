package main
import "fmt"

const University = "ELTE"
func main() {
	const threshold = 12
	fmt.Println(University+" Informatics")
	fmt.Println(threshold+1)
}