package main
import "fmt"
func main() {
    var i = 1
    j := 2       // short assignment
    fmt.Println(i, j)
}
