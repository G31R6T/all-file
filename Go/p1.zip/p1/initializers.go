package main
import "fmt"
var i = 1
var j int = 2
func main() {
	var x, y = true, "hello"
	fmt.Println(i, j, x, y)
}
