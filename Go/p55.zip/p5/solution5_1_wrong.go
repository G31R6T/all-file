package main

import (
	"fmt"
)

func main() {
	c := make(chan string)
	
	r := <- c
	
	go func(){
		c <- "Hello"
	}()
	
	fmt.Println(r)
}