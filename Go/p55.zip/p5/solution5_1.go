package main

import (
	"fmt"
)

func main() {
	c := make(chan string)
	
	go func(){
		c <- "Hello"
	}()
	
	r := <- c
	
	fmt.Println(r)
}