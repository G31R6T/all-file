package main

import (
	"fmt"
	"time"
	"sync"
)

func main() {
	c := make(chan int, 5)
	var wg sync.WaitGroup

	wg.Add(1)
	go func(){
		defer wg.Done()
		for i:= 0; i < 10; i++ {
			c <- i
			fmt.Println("g1 sent ", i)
		}
	}()
	
	go func(){
		wg.Wait()
		for i:= 0; i < 10; i++ {
			c <- i
			fmt.Println("g2 sent ", i)
		}
		close(c)
	}()
	
	time.Sleep(2 * time.Second)
	
	start := time.Now()
	for r:= range c {
		fmt.Println("main received ", r)
	}
	duration := time.Since(start)
    fmt.Println("Time: ", duration)
}