//Author:   lizhipeng
//Date:     2021.5.5.
//Title:    classes of prey species

#pragma once

#include <string>

// class of the abstract animal
class Animal{
protected:
    std::string _name;
    char _species;
    int _numberOfAnimals;
    Animal (const std::string &str1, char s, int n) :_name(str1), _species(s), _numberOfAnimals(n) {}
public:
    std::string name() const { return _name; }
    char species() const { return _species; }
    int num() const { return _numberOfAnimals; }
    void setNum(int n){ _numberOfAnimals = n; }
    virtual ~Animal () {}
};

class Prey : public Animal{
private:
	int _decreasedTimes; // when attacked by predator, the times of the number of predator decreasesed
public:
	Prey (const std::string &str1, char s, int n, int decreasedTimes) : Animal(str1, s, n), _decreasedTimes(decreasedTimes) {}

	// predator attack prey, return the number of predator who didn't get prey
    int preyed(int predatorNum) {
    	// enough four times the number of predators in the colony
    	if(num() >= (_decreasedTimes * predatorNum)){
    		setNum(num() - _decreasedTimes * predatorNum); // change the number of prey
    		return 0;
    	} else {
    		int predatorEat = num() / _decreasedTimes;
    		setNum(num() - _decreasedTimes * predatorEat); // change the number of prey
    		return predatorNum - predatorEat;
    	}
    }

    virtual void grow(int turn) = 0;
    virtual ~Prey () {}
};

// class of Lemming
class Lemming : public Prey {
public:
	Lemming (const std::string &str1, char s, int n, int decreasedTimes) :Prey(str1, s, n, decreasedTimes) {}
	// The number of animals in their colony doubles every second turn,
	// If there are more than 200 animals in the colony, the number of animals in the colony decreases to 30
	void grow(int turn){
		if(turn % 2 == 0){
			int newNum = 2 * num();
			if(newNum > 200){
				newNum = 30;
			}
			setNum(newNum);
		}
	}
};

// class of Hare
class Hare : public Prey {
public:
	Hare (const std::string &str1, char s, int n, int decreasedTimes) :Prey(str1, s, n, decreasedTimes) {}
	// The number of animals in their colony grows by 50 percent every second turn
	// If there are more than 100 animals in the colony, the number of animals in the colony decreases to 20.
	void grow(int turn){
		if(turn % 2 == 0){
			int newNum = 1.5 * num();
			if(newNum > 100){
				newNum = 20;
			}
			setNum(newNum);
		}
	}
};

// class of Gopher
class Gopher : public Prey {
public:
	Gopher (const std::string &str1, char s, int n, int decreasedTimes) :Prey(str1, s, n, decreasedTimes) {}
	// The number of animals in their colony doubles every fourth turn,
	// If there are more than 200 animals in the colony, the number of animals in the colony decreases to 40.
	void grow(int turn) {
		if (turn % 4 == 0) {
			int newNum = 2 * num();
			if (newNum > 200) {
				newNum = 40;
			}
			setNum(newNum);
		}
	}
};

