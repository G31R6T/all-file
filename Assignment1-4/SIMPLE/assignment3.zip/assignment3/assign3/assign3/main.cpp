//Author:       lizhipeng
//Date:          2021.05.05.
//Title:         Competition of animals

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <vector>
#include "prey.h"
#include "predator.h"

using namespace std;

//Task:          Filling the vector of preies and the predators from a file of a given name
//Input:         string str	- name of the text file
//Output:        vector<Prey*> &preies  - vector of pointers of the preies
//               vector<Predator*> &predators - vector of the grounds of the predators
//Activity:      creating the animals and their pointers
//               filling the vector of preies
//               filling the vector of the predators
void create(const string &str, vector<Prey*> &preies, vector<Predator*> &predators)
{
    ifstream f(str);
    if(f.fail()) { cout << "Wrong file name!\n"; exit(1);}

    // population of the preies
    int n, m;
    f >> n >> m;
    preies.resize(n);
    string name; char species; int num;
    for( int i=0; i<n; ++i ){
        f >> name >> species >> num;
        switch(species){
            case 'l' : preies[i] = new Lemming(name, species, num, 4); break;
            case 'h' : preies[i] = new Hare(name, species, num, 2); break;
            case 'g' : preies[i] = new Gopher(name, species, num, 2); break;
        }
    }

    // population of the predators
    predators.resize(m);
    for( int j=0; j<m; ++j ) {
    	f >> name >> species >> num;
        switch(species){
            case 'o' : predators[j] = new Owl(name, species, num); break;
            case 'f' : predators[j] = new Fox(name, species, num); break;
            case 'w' : predators[j] = new Wolf(name, species, num); break;
            default: cout << "Invalid predator: " << name << " " << species << " " << num << endl; exit(1);
        }
    }
}

//Task:       Check if the simulate process is finished
//Input:      vector<Ground*> &predators - vector of the grounds of the predators
//Output:     true if the process is finished, else return false
//Activity:   check the number of animals in each predator colony decreases to below 4,
//            or the number of predators doubles compared to its starting value
bool isFinished(vector<Predator*> &predators)
{
	bool allDouble = true;
	bool allBelow4 = true;
	for(int i = 0;i < predators.size();i++){
		if(predators[i]->num() >= 4){
			allBelow4 = false;
		}
		if(!(predators[i]->isNumDouble())){
			allDouble = false;
		}
	}
	return allDouble || allBelow4;
}

//Task:       The competition
//Input:      vector<Prey*> &preies  - vector of pointers of the preies
//            vector<Predator*> &predators - vector of pointers of the predators
//Output:     vector<Prey*> &preies  - vector of pointers of the preies
//            vector<Predator*> &predators - vector of pointers of the predators
//Activity:   predator randomly attack prey
void race(vector<Prey*> &preies, vector<Predator*> &predators)
{
	cout << "Number of animals in every turn:" << endl;
	// Predators choose and attack a prey colony randomly in each turn
	int turn = 1;
	while(!isFinished(predators)){
		for(int j = 0;j < preies.size();j++){
			preies[j]->grow(turn);
		}
		for (int i = 0; i < predators.size(); i++) {
			predators[i]->offsprings(turn);
			predators[i]->attack(preies);
		}
		// Print the data of each colony in each turn
		cout << "\nturn " << turn << endl;
		cout << "name\tspecies\tnumber_of_animals" << endl;
		for(int i = 0;i < preies.size();i++){
			cout << preies[i]->name() << "\t";
			cout << preies[i]->species() << "\t";
			cout << preies[i]->num() << endl;
		}
		for(int i = 0;i < predators.size();i++){
			cout << predators[i]->name() << "\t";
			cout << predators[i]->species() << "\t";
			cout << predators[i]->num() << endl;
		}
		turn++;
	}
}

//Task:       Destruction of the preies and predators
//Input:      vector<Prey*> &preies  - vector of pointers of the preies
//            vector<Predator*> &predators  - vector of pointers of the predators
//Activity:   destroys every dinamically allocated preies and predators
void destroy(vector<Prey*> preies, vector<Predator*> predators)
{
    for(int i=0; i<(int)preies.size(); ++i) {
    	delete preies[i];
    }
    for(int i=0; i<(int)predators.size(); ++i) {
    	delete predators[i];
    }
}

// To change between the manual and the unit test mode
#define NORMAL_MOD
#ifdef NORMAL_MOD


//Task:       Competition for colonies of prey and predator animals
//Input:      text file
//Output:     the data of each colony in each turn written to the console
//Activity:   Creating the preies and the predators based on the file
//            Simulation of the competition and writing the result
int main()
{
	string inputName;
	cout << "Please enter input file name: ";
	cin >> inputName;
    vector<Prey*> preies;
    vector<Predator*> predators;
    create(inputName, preies, predators);

    // Competition
    race(preies, predators);
    // Destruction of the objects
    destroy(preies, predators);
    return 0;
}

#else
#define CATCH_CONFIG_MAIN
#include "catch.hpp"

TEST_CASE("1", "inp11.txt")
{
    vector<Prey*> preies;
    vector<Predator*> predators;
    create("inp11.txt", preies, predators);
    CHECK(preies.size() == 3);
    CHECK(predators.size() == 3);
    destroy(preies, predators);
}

TEST_CASE("2", "inp12.txt")
{
    vector<Prey*> preies;
    vector<Predator*> predators;
    create("inp12.txt", preies, predators);
    CHECK(preies.size() == 3);
    CHECK(predators.size() == 3);
    CHECK(isFinished(predators));
    destroy(preies, predators);
}

TEST_CASE("3", "inp13.txt")
{
    vector<Prey*> preies;
    vector<Predator*> predators;
    create("inp13.txt", preies, predators);
    CHECK(preies.size() == 0);
    CHECK(predators.size() == 3);
    CHECK(isFinished(predators));
    destroy(preies, predators);
}

TEST_CASE("4", "inp21.txt")
{
    vector<Prey*> preies;
    vector<Predator*> predators;
    create("inp21.txt", preies, predators);
    CHECK(preies.size() == 3);
    CHECK(predators.size() == 0);
    CHECK(isFinished(predators));
    destroy(preies, predators);
}

TEST_CASE("5", "inp22.txt")
{
    vector<Prey*> preies;
    vector<Predator*> predators;
    create("inp22.txt", preies, predators);
    CHECK(preies.size() == 0);
    CHECK(predators.size() == 0);
    CHECK(isFinished(predators));
    destroy(preies, predators);
}

TEST_CASE("6", "inp31.txt")
{
    vector<Prey*> preies;
    vector<Predator*> predators;
    create("inp31.txt", preies, predators);
    CHECK(preies.size() == 3);
    CHECK(predators.size() == 3);
    CHECK(!isFinished(predators));
    race(preies, predators);
    for(int i = 0;i < predators.size();i++){
    	CHECK(predators[i]->num() == 3);
    }
    destroy(preies, predators);
}

TEST_CASE("7", "inp32.txt")
{
    vector<Prey*> preies;
    vector<Predator*> predators;
    create("inp32.txt", preies, predators);
    CHECK(preies.size() == 3);
    CHECK(predators.size() == 3);
    CHECK(!isFinished(predators));
    race(preies, predators);
    bool hasZero = false;
    for(int i = 0;i < preies.size();i++){
    	if(preies[i]->num() == 0){
    		hasZero = true;
    	}
    }
    CHECK(hasZero);
    destroy(preies, predators);
}
#endif // NORMAL_MODE
