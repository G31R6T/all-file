//Author:   lizhipeng
//Date:     2021.5.5.
//Title:    classes of prey species

#pragma once

#include <string>
#include <vector>
#include <cstdlib>
#include "prey.h"

// class of the abstract Predator
class Predator : public Animal{
private:
	int startingNum;
public:
	Predator (const std::string &str1, char s, int n = 0) :Animal(str1, s, n) {
		this->startingNum = n;
	}
	bool isNumDouble() {return (this->num() / startingNum) >= 2; };

	// choose and attack a prey colony randomly in each turn,
	// every fourth predator out of the ones who didn't get prey perishes
    void attack(std::vector<Prey*> &preies){
    	// if no prey, decrease the number of predator
    	if(preies.size() == 0){
    		setNum(num() * 0.75);
    		return;
    	}
    	int numNoPrey; // the number of predator who didn't get prey
    	int preyIndex = rand() % preies.size();
    	numNoPrey = preies[preyIndex]->preyed(num());
    	setNum(num() - numNoPrey * 0.25);
    }

    virtual void offsprings(int turn) = 0;
    virtual ~Predator () {}
};

// class of Owl
class Owl : public Predator {
public:
	Owl (const std::string &str1, char s, int n = 0) :Predator(str1, s, n) {}
	// Predators have offsprings every eighth turn,
	// the snow owls have 1 offspring per 4 animals
    void offsprings(int turn) {
    	if(turn % 8 == 0) {
        	int newNum = 1 * (num() / 4) + num();
        	setNum(newNum);
    	}
    }
};

// class of Fox
class Fox : public Predator {
public:
	Fox (const std::string &str1, char s, int n = 0) :Predator(str1, s, n) {}
	// Predators have offsprings every eighth turn,
	// the foxes have 3 offsprings per 4 animals
    void offsprings(int turn) {
    	if(turn % 8 == 0) {
    		int newNum = 3 * (num() / 4) + num();
    		setNum(newNum);
    	}
    }
};

// class of Wolf
class Wolf : public Predator {
public:
	Wolf (const std::string &str1, char s, int n = 0) :Predator(str1, s, n) {}
	// Predators have offsprings every eighth turn,
	// the wolves have 2 offsprings per 4 animals
    void offsprings(int turn) {
    	if(turn % 8 == 0) {
    		int newNum = 2 * (num() / 4) + num();
    		setNum(newNum);
    	}
    }
};

