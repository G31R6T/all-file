package exam.findsuitablejob;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class EmpAgency extends Contract {
	private List<Employee> employees;

	public EmpAgency(String degree, int contractPeriod, Employee... employees) {
		super(degree, employees.length, contractPeriod);
		this.employees = new ArrayList<Employee>();
		for(Employee employee : employees){
			this.employees.add(employee);
		}
	}
	
	public static Employee[] load(String filePath) {
		List<Employee> employees = new ArrayList<Employee>();
		try {
			Scanner scanner = new Scanner(new File(filePath));
			String line;
			Employee employee = null;
			while (scanner.hasNext()) {
				line = scanner.nextLine();
				if(line != null){
					employee = Employee.make(line);					
				}
				if (employee != null) {
					employees.add(employee);
				}
			}
			scanner.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return employees.toArray(new Employee[0]);
	}

	public void hire(Position position) {
		Collections.sort(this.employees);
		Iterator<Employee> iterator = this.employees.iterator();
		Employee employee;
		while (iterator.hasNext()) {
			employee = iterator.next();
			if(employee.getSalary() <= Contract.getGoalSalary()){
				employee.getHiredAt(position);
				numberOfEmployees += 1;
				iterator.remove();
			}
		}
	}

	public double getMaxIncrease(double increaseRate) {
		double maxIncrease = 0;
		double increase;
		if (this.getNumberOfEmployees() == 0) {
			throw new IllegalStateException();
		}
		Iterator<Employee> iterator = employees.iterator();
		Employee employee;
		while (iterator.hasNext()) {
			employee = iterator.next();
			increase = employee.getSalary() * increaseRate;
			if (increase > maxIncrease) {
				maxIncrease = increase;
			}
		}
		return maxIncrease;
	}

	public String toString() {
		String allEmployees = "";
		Iterator<Employee> iterator = employees.iterator();
		Employee employee;
		while (iterator.hasNext()) {
			allEmployees += iterator.next().toString() + "\n";
		}
		return allEmployees;
	}
}