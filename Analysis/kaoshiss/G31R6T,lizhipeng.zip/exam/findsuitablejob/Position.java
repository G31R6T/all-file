package exam.findsuitablejob;

public enum Position {
	FREELANCER(7000), UNIVERSITY(4000), HOSPITAL(5000), ITCOMPANY(2700);
	int salary;
	
	Position(int salary){
		this.salary = salary;
	}

	public int getSalary() {
		return salary;
	}
	
}