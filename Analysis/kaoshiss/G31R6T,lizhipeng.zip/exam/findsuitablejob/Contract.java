package exam.findsuitablejob;

public class Contract {
	protected String degree;
	protected int numberOfEmployees;
	protected int contractPeriod;
	protected static int goalSalary = 4000;
	private static int MIN_PERIOD = 6;
	private static int MAX_PERIOD = 12;
	private static int MIN_EMPLOYEE = 15;
	private static int MAX_EMPLOYEE = 40;

	public String getDegree() {
		return degree;
	}

	public int getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public int getContractPeriod() {
		return contractPeriod;
	}

	public static int getGoalSalary() {
		return goalSalary;
	}

	public static void setGoalSalary(int goalSalary) {
		Contract.goalSalary = goalSalary;
	}

	public boolean isBetween(int number, int min, int max) {
		if (number >= min && number <= max) {
			return true;
		} else {
			return false;
		}
	}

	public Contract(){
		this("Master", 20, 12);
	}
	
	public Contract(String degree, int numberOfEmployees, int contractPeriod) {
		super();
		this.degree = degree;
		this.numberOfEmployees = numberOfEmployees;
		this.contractPeriod = contractPeriod;
		if (!isBetween(contractPeriod, MIN_PERIOD, MAX_PERIOD)) {
			throw new IllegalArgumentException();
		}
		if (!isBetween(numberOfEmployees, MIN_EMPLOYEE, MAX_EMPLOYEE)) {
			throw new IllegalArgumentException();
		}
	}

	public static void main(String[] args) {
		new Contract("abc", 15, 6);
	}
}