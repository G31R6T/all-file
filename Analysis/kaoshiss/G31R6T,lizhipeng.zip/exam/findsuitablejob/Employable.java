package exam.findsuitablejob;

public interface Employable {
	public void getHiredAt(Position position);
	public double getSalaryIncrease(double increaseRate);
}