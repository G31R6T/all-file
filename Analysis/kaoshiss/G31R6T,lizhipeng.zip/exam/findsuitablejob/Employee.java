package exam.findsuitablejob;

public class Employee implements Employable, Comparable<Employee>{
	private String employeeName;
	private int salary = 0;

	private Employee(String employeeName, int salary) {
		super();
		this.employeeName = employeeName;
		this.salary = salary;
		if (employeeName == null) {
			throw new IllegalArgumentException();
		}
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public int getSalary() {
		return salary;
	}

	public static Employee make(String data) {
		String values[] = data.split(",");
		String employeeName = values[0].trim();
		int salary = -1;
		try {
			salary = Integer.parseInt(values[1].trim());
		} catch (Exception e) {
			salary = -1;
//			throw new NumberFormatException(data);
		}
		if (employeeName.length() == 0 || values.length != 2 || salary < 0) {
			return null;
		} else {
			return new Employee(employeeName, salary);
		}
	}

	public boolean equals(Object obj) {
		Employee e = (Employee)obj;
		if(this.getEmployeeName().equals(e.getEmployeeName()) && this.getSalary() == e.getSalary()){
			return true;
		} else {
			return false;
		}
	}
	
	public int hashCode() {
		return employeeName.hashCode() + new Integer(salary).hashCode();
	}
	
	public String toString() {
		return employeeName + "," + salary;
	}
	
	
	public void getHiredAt(Position position) {
		this.salary += position.getSalary();
	}

	public double getSalaryIncrease(double increaseRate) {
		if(increaseRate < 1.1){
			throw new IllegalArgumentException();
		} else {
			return this.salary * increaseRate;
		}
	}

	public int compareTo(Employee o) {
		return new Integer(this.salary).compareTo(new Integer(o.getSalary()));
	}

}