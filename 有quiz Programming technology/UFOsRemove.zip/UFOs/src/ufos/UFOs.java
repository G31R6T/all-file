/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ufos;

/**
 *
 * @author bli
 */
public class UFOs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        UFOGUI gui = new UFOGUI(10);
    }
    
}
