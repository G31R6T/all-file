/**
 * G31R6T 
 * Li zhipeng
 * BlackHole Game 
 */
package assign;

import java.awt.*; //����ͼ�����
import java.awt.event.*;//�����¼�����
import javax.swing.*;

import javazoom.jl.decoder.JavaLayerException;

import java.util.*;//arry

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

import javazoom.jl.player.Player;






public class BlackHole extends JFrame  implements ActionListener {
      
	 /**
	 * Import picture effects
	 */
	private static final long serialVersionUID = 1L;
	Image RedShip =this.getToolkit().getImage("pic/red.png");
	 Image BlueShip =this.getToolkit().getImage("pic/blue.png");
	 Image Heidong =this.getToolkit().getImage("pic/blackhole.png");
	 Image BackImg1 =this.getToolkit().getImage("pic/bk.png");
	 Image BackImg2 =this.getToolkit().getImage("pic/beijing2.png");
	 Image RedSel =this.getToolkit().getImage("pic/red_selected.png");
	 Image BlueSel =this.getToolkit().getImage("pic/blue_selected.png");
	 
	 
	
	  JPanel Selectmb,Temp;    //ѡ����� Select Off Panel
      JLabel Levelselect;  //ѡ����ʾ���ֱ�ǩ Prompt text label for selection
      JButton Okbutton;  //ȷ����ť Confirm button
      JComboBox<String> Levelitem; //��ѡ����� ѡ�� Select
     int[][] DT1= new int[5][5];   //��һ�� 25��ͨ�б�� first round
     int[][] DT2= new int[7][7];   //�ڶ���79��ͨ�б�� Second round
     int[][] DT3= new int[9][9];   //������81��ͨ�б�� Third round
     
     int Redscore; //�췽�÷� Red team score
     int Bluescore;//�����÷� Blue team score
     
     int DtLevel;//�ؿ����� Level
     int TurnS=11;  //  11-�����췽�ж� red move 22-���������ж� blue move
     int Seled=0;  //ѡ����� ����һ���ɴ���ѡ�н����ƶ����� Mobile operation
     int BottomMax,RightMax; //�����ӵĵײ��߽���ұ߽߱� The bottom and right borders of the panel grid
     int Centerx=2;
     int Centery=2;//�ڶ����� Black hole coordinates
     int Currentx=0;//��ǰѡ�зɴ���X���� X coordinate of the spaceship
     int Currenty=0;//��ǰѡ�зɴ���Y���� Y coordinate of the spaceship
     String[] Litem= {"5*5map","7*7map","9*9map"};//�ؿ���ͼ���ֱ��� Map text title

     //DT1  round 1 The initial coordinates of the red and blue spacecraft
     int[] RedPosxDT1= {0,1,3,4};
     int[] RedPosyDT1={0,1,1,0};
     int[] BluePosxDT1={0,1,3,4}; 
     int[] BluePosyDT1={4,3,3,4}; 
   
     //DT2  round 2
     int[] RedPosxDT2= {0,1,2,4,5,6};
     int[] RedPosyDT2={0,1,2,2,1,0};
     int[] BluePosxDT2={0,1,2,4,5,6}; 
     int[] BluePosyDT2={6,5,4,4,5,6};
   
     //DT3  round 3
     int[] RedPosxDT3= {0,1,2,3,5,6,7,8};
     int[] RedPosyDT3={0,1,2,3,3,2,1,0};
     int[] BluePosxDT3={0,1,2,3,5,6,7,8}; 
     int[] BluePosyDT3={8,7,6,5,5,6,7,8};   

     int WinScore=2;//��ʤ���� Winning score criteria
	   
	 Wdmb mb=null;//���������� Declare the main form


	 public static Player player = null; //Import mp3

	
	 
	 public static void PlayBG() {

			try {
				//File 
				File mp3 = new File("sound/music.mp3");
				
				//input
				FileInputStream fileInputStream = new FileInputStream(mp3);
				
				
				BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
				
				
				player = new Player(bufferedInputStream);
				
	                    
				new Thread(()->{
					// Call the play method to play
					try {
						player.play();
					} catch (JavaLayerException e) {
						e.printStackTrace();
					}
				}).start(); 
				
				Thread.sleep(1000);
				//player.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 public static void PlayStart() {

			try {
				//File
				File mp3 = new File("sound/start.mp3");
				
				//input
				FileInputStream fileInputStream = new FileInputStream(mp3);
				
		
				BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
				
				
				player = new Player(bufferedInputStream);
				
	                    
				new Thread(()->{
					// Call the play method to play
					try {
						player.play();
					} catch (JavaLayerException e) {
						e.printStackTrace();
					}
				}).start(); 
				
				Thread.sleep(1000);
				player.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
//===============================================================================

      public  void init(){  //ÿ�ֽ�����ı�����ʼ�� Variable initialization after each round
            
    	 
    	  
    	  
            Redscore=0; //�췽�÷����� Red team score cleared
            Bluescore=0;//�����÷����� blue team score cleared
            TurnS=11;  //�췽���� Red side first
            Seled=0;  //Ĭ��ѡ�е�һ�ҷɴ� The  first ship is selected by default
           //DT1 ��һ�صĳ�ʼ������ Initialization data of the first level
     
          RedPosxDT1=new int[4]; //Array empty
          RedPosyDT1=new int[4]; 
          BluePosxDT1=new int[4];
          BluePosyDT1=new int[4];

          //�췽�ɴ���ʼXY���� The initial XY coordinates of the red spacecraft
          RedPosxDT1[0]=0;
          RedPosxDT1[1]=1;
          RedPosxDT1[2]=3;
          RedPosxDT1[3]=4;
          RedPosyDT1[0]=0;
          RedPosyDT1[1]=1;
          RedPosyDT1[2]=1;
          RedPosyDT1[3]=0;


          //�����ɴ���ʼXY���� The initial XY coordinates of the blue spacecraft
          BluePosxDT1[0]=0;
          BluePosxDT1[1]=1;
          BluePosxDT1[2]=3;
          BluePosxDT1[3]=4;
          BluePosyDT1[0]=4;
          BluePosyDT1[1]=3;
          BluePosyDT1[2]=3;
          BluePosyDT1[3]=4;
   
     //DT2 �ڶ��صĳ�ʼ������ Initialization data of the second level
          RedPosxDT2=new int[6]; 
          RedPosyDT2=new int[6]; 
          BluePosxDT2=new int[6];
          BluePosyDT2=new int[6];
          
          //�췽�ɴ���ʼXY���� The initial XY coordinates of the red spacecraft
          RedPosxDT2[0]=0;
          RedPosxDT2[1]=1;
          RedPosxDT2[2]=2;
          RedPosxDT2[3]=4;
          RedPosxDT2[4]=5;
          RedPosxDT2[5]=6;
          RedPosyDT2[0]=0;
          RedPosyDT2[1]=1;
          RedPosyDT2[2]=2;
          RedPosyDT2[3]=2;
          RedPosyDT2[4]=1;
          RedPosyDT2[5]=0;
          
          //�����ɴ���ʼXY���� The initial XY coordinates of the blue spacecraft
          BluePosxDT2[0]=0;
          BluePosxDT2[1]=1;
          BluePosxDT2[2]=2;
          BluePosxDT2[3]=4;
          BluePosxDT2[4]=5;
          BluePosxDT2[5]=6;
          BluePosyDT2[0]=6;
          BluePosyDT2[1]=5;
          BluePosyDT2[2]=4;
          BluePosyDT2[3]=4;
          BluePosyDT2[4]=5;
          BluePosyDT2[5]=6;
          
     //RedPosxDT2= {0,1,2,4,5,6};
     //RedPosyDT2={0,1,2,2,1,0};
     //BluePosxDT2={0,1,2,4,5,6}; 
     //BluePosyDT2={6,5,4,4,5,6};
   
     //DT3 �����صĳ�ʼ������ Initialization data of the third level
          RedPosxDT3=new int[8]; 
          RedPosyDT3=new int[8]; 
          BluePosxDT3=new int[8];
          BluePosyDT3=new int[8];
          
          //�췽�ɴ���ʼXY���� The initial XY coordinates of the red spacecraft
          RedPosxDT3[0]=0;
          RedPosxDT3[1]=1;
          RedPosxDT3[2]=2;
          RedPosxDT3[3]=3;
          RedPosxDT3[4]=5;
          RedPosxDT3[5]=6;
          RedPosxDT3[6]=7;
          RedPosxDT3[7]=8;         
          RedPosyDT3[0]=0;
          RedPosyDT3[1]=1;
          RedPosyDT3[2]=2;
          RedPosyDT3[3]=3;
          RedPosyDT3[4]=3;
          RedPosyDT3[5]=2;
          RedPosyDT3[6]=1;
          RedPosyDT3[7]=0;
          
          
          //�����ɴ���ʼXY���� The initial XY coordinates of the blue spacecraft
          BluePosxDT3[0]=0;
          BluePosxDT3[1]=1;
          BluePosxDT3[2]=2;
          BluePosxDT3[3]=3;
          BluePosxDT3[4]=5;
          BluePosxDT3[5]=6;
          BluePosxDT3[6]=7;
          BluePosxDT3[7]=8;
          BluePosyDT3[0]=8;
          BluePosyDT3[1]=7;
          BluePosyDT3[2]=6;
          BluePosyDT3[3]=5;
          BluePosyDT3[4]=5;
          BluePosyDT3[5]=6;
          BluePosyDT3[6]=7;
          BluePosyDT3[7]=8;
    //  RedPosxDT3= {0,1,2,3,5,6,7,8};
    //  RedPosyDaT3={0,1,2,3,3,2,1,0};
    //  BluePosxDT3={0,1,2,3,5,6,7,8}; 
    //  BluePosyDT3={8,7,6,5,5,6,7,8};   


     
      }
     
//=============================================================================











     //  @SuppressWarnings("unchecked")  //�رռ�鱨��
	public static void main(String[] args) {  
	      
        new BlackHole();    //��������Implement construction method Create window

        
        

	}
	
    public void actionPerformed(ActionEvent e)   //�¼�����
	{
		

                 

		 if(e.getActionCommand().equals("111"))  //After the level map is selected, click the OK button to execute
		 { 
			
			 PlayStart();
			 this.dispose();  //����ԭ���� Destroy the original form
			 String LevelDT = Levelitem.getSelectedItem().toString(); //selected map name
			 if (LevelDT=="5*5map") {
				                   WinScore=2;  // how win
                                   BottomMax=4; //boundary
                                   RightMax=4;  
                                   Centerx=2;   // Black hole x coordinate
                                   Centery=2;   //Black hole y coordinate
                                   Seled=0;    
                                  
				new BlackHole(1); //open window
				
                                
				
			 }
			 if (LevelDT=="7*7map") {
				                  WinScore=3;
                                  BottomMax=6;
                                   RightMax=6; 
                                   Centerx=3;
                                   Centery=3;
                                   Seled=0;
				 new BlackHole(2);
                                 
				
			 }
			 if (LevelDT=="9*9map") {
				                  WinScore=4;
                                  BottomMax=8;
                                   RightMax=8; 
                                   Centerx=4;
                                   Centery=4;
                                   Seled=0;
				 new BlackHole(3);
				 
			 }
			 
			 
		 }
		 
	}
    
	
	
	
	
	 BlackHole()  {  //���췽�� Construction method
	
		Selectmb = new JPanel(); //ѡ����� Select Off Panel
		
		Selectmb.setLayout(new FlowLayout(FlowLayout.LEFT,350,100));//��ʽ����

	Levelselect = new JLabel("Blackhole Game ");  //name title
	Levelselect.setFont(new Font("��Բ", Font.BOLD, 50)); 
	Levelselect.setForeground(Color.red);  //color
		Levelitem= new JComboBox(Litem);   //Drop down box
		Levelitem.setFont(new Font("��Բ", Font.BOLD, 60)); 
		Okbutton = new JButton("GO");  //ȷ�ϰ�ť Confirm button
		Okbutton.setFont(new Font("��Բ", Font.BOLD, 60));
		Selectmb.add(Levelselect);  //���ӱ�ǩ����� Add tags to the panel
		Selectmb.add(Levelitem);    //������������� Add a drop-down box to the panel
		Selectmb.add(Okbutton);     //���Ӱ�ť����� Add buttons to the panel

		 
		Okbutton.addActionListener(this);  //���ð�ť����
		
		Okbutton.setActionCommand("111");  //���ð�ť�������
		
		
		
		this.add(Selectmb);  //�������봰�� Put the panel into the form
		
		this.setTitle("BlackHole"); //���ô��ڱ��� Set window title
	 
		this.setSize(1024,768); //���ô��ڴ�С Set the window size
		this.setDefaultCloseOperation(EXIT_ON_CLOSE); //�رմ���ʱע������ Log off the process when closing the window
		this.setResizable(false);   //���ɵ������ڴ�С Can't adjust window size
		this.setLocationRelativeTo(null);  //���ô�������Ļ���� The setting window is in the center of the screen
        this.setVisible(true);		 //��ʾ���� Display window
        
	}
	
	
 





	
	public BlackHole(int Sel) {

        switch (Sel) {
        
        case 1:        	    		
    		 DtLevel=1;    		     //��һ��
    		this.setTitle("5*5map");  //����
    		//��ͼ��λ��ʼ��
    		for ( int m=0;m<5;m++) {
    				for( int n=0 ;n<5;n++) {
    				DT1[m][n]=0;
    				}
    		}

    		DT1[2][2]=9;//9�����ڶ�
    		
    		DT1[0][0]=1;
    		DT1[1][1]=1;
    		DT1[4][0]=1;
    		DT1[3][1]=1;//��������д����촬��
    		
    		
    		DT1[0][4]=1;
    		DT1[1][3]=1;    		   		
    		DT1[4][4]=1;
    		DT1[3][3]=1;//��������д���������
    		
           Seled=0;
                  
        	break;
        	
        case 2:        	
    		 DtLevel=2;    		
    		this.setTitle("7*7map"); 
    		//��ͼ��λ��ʼ��
    		for ( int m=0;m<7;m++) {
    				for( int n=0 ;n<7;n++) {
    				DT2[m][n]=0;
    				}
    		}

    		DT2[3][3]=9;//9�����ڶ�
    		
    		DT2[0][0]=1;
    		DT2[1][1]=1;
    		DT2[2][2]=1;
    		DT2[4][2]=1;
    		DT2[5][1]=1;
    		DT2[6][0]=1;
    		
    		
    		
    		DT2[0][6]=1;
    		DT2[1][5]=1;    		   		
    		DT2[2][4]=1;
    		DT2[4][4]=1;
    		DT2[5][5]=1;    		   		
    		DT2[6][6]=1;
    		
    		
           Seled=0;
    		
    		
    		
        	break;
        	
        case 3:        	    		
    		 DtLevel=3;
    		this.setTitle("9*9map");  
    		
    		//��ͼ��λ��ʼ��
    		for ( int m=0;m<9;m++) {
    				for( int n=0 ;n<9;n++) {
    				DT3[m][n]=0;
    				}
    		}

    		DT3[4][4]=9;//9�����ڶ�
    		
    		DT3[0][0]=1;
    		DT3[1][1]=1;
    		DT3[2][2]=1;
    		DT3[3][3]=1;
    		DT3[5][3]=1;
    		DT3[6][2]=1;
    		DT3[7][1]=1;
    		DT3[8][0]=1;
    		
    		
    		
    		DT3[0][8]=1;
    		DT3[1][7]=1;    		   		
    		DT3[2][6]=1;
    		DT3[3][5]=1;
    		DT3[5][5]=1;
    		DT3[6][6]=1;    		   		
    		DT3[7][7]=1;
    		DT3[8][8]=1;
           Seled=0;
    		
    		
        	break;          
        }
        Redscore=0;
		Bluescore=0;    		
		mb=new Wdmb();
		 this.add(mb);
		 this.addKeyListener(mb); 
		 if (DtLevel==1) {
			 this.setSize(410,480);
		 }
		 if (DtLevel==2) {
			 this.setSize(570,640);
		 }
		 if (DtLevel==3) {
			 this.setSize(730,800);
		 }
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setLocationRelativeTo(null);  //���ô�������Ļ����
        this.setVisible(true);	
        PlayBG();
		
	}

	class Wdmb extends JPanel implements KeyListener
	{
		int x=1,y=50;
		

         
               public void paint(Graphics g) //��������Ǹ��Ǹ���ķ��������ʵ���˼
		{
            	  
            	  
                      //ȡ��ǰ���Ʒɴ�������    
            	   if(TurnS==11) {
            		   switch(DtLevel) {
            		   case 1:
            			   Currentx=RedPosxDT1[Seled];
                           Currenty=RedPosyDT1[Seled];
            			   break;
            		   case 2:
            			   Currentx=RedPosxDT2[Seled];
                           Currenty=RedPosyDT2[Seled];
            			   break;
            		   case 3:
            			   Currentx=RedPosxDT3[Seled];
                           Currenty=RedPosyDT3[Seled];
            			   break;
            		   }
   		              
   			      }else{
   			    	  
	   			    	switch(DtLevel) {
		         		   case 1:
		         			    Currentx=BluePosxDT1[Seled];
		   	                    Currenty=BluePosyDT1[Seled];
		         			   break;
		         		   case 2:
		         			    Currentx=BluePosxDT2[Seled];
		   	                    Currenty=BluePosyDT2[Seled];
		         			   break;
		         		   case 3:
		         			    Currentx=BluePosxDT3[Seled];
		   	                    Currenty=BluePosyDT3[Seled];
		         			   break;
	         		   }
	   			    	  
   			    	  
   			    	  
   			    	   
   			      }
			super.paint(g);
			// g.drawImage(BackdImg, 0, 0, this);
			g.setColor(Color.BLACK);
			g.setFont(new Font("΢���ź�",Font.BOLD, 15));
			g.drawString("Red SCORE ",10,20);	
			g.drawString(Integer.toString(Redscore),10,40);
			g.drawString("Blue SCORE ",180, 20);
			g.drawString(Integer.toString(Bluescore),180, 40);
                        g.setColor(Color.RED);
                       
                        
		
			g.setColor(Color.darkGray);

			
			
			
			if(DtLevel==1) {

                        //����ͼ
			
				
				g.drawImage(BackImg2,1,50,400,400, this);
			
			
			//==========================================================================
			//���촬                                     
                              
			 for (int n=0 ;n<RedPosyDT1.length;n++){
				
				 g.drawImage(Heidong,1+Centerx*80,50+Centery*80,80,80, this);
			 
                    if(n==Seled && TurnS==11) {
                    
                    	g.drawImage(RedSel, 1+RedPosxDT1[Seled]*80,50+RedPosyDT1[Seled]*80,80,80, this);
                    }else {
				 
				  g.drawImage(RedShip, 1+RedPosxDT1[n]*80, 50+RedPosyDT1[n]*80,80,80, this);
                          
                    } 
                           }

                          //������
                                      for (int n=0 ;n<BluePosxDT1.length;n++){
                                         
                                    	  g.drawImage(Heidong,1+Centerx*80,50+Centery*80,80,80, this);
                           
                                    if (TurnS ==22 && n==Seled ){

                                   
                                    	g.drawImage(BlueSel, 1+BluePosxDT1[n]*80,50+BluePosyDT1[n]*80,80,80, this);
                                  
                               }else {
                            	   
                            	
                            	   g.drawImage(BlueShip, 1+BluePosxDT1[n]*80,50+BluePosyDT1[n]*80,80,80, this);
                            	   
                               }
                        

                       
                                   
                           }
                              //=================================================================================
                                      g.drawString("X:"+Integer.toString(Currentx),320, 40);
                                      g.drawString("Y:"+Integer.toString(Currenty),370, 40);
                                      
			
			}
			
			
			if(DtLevel==2) {
                     Centerx=3;
                     Centery=3;
				              //����ͼ
                     g.drawImage(BackImg2,1,50,560,560, this);
					//g.setColor(Color.BLACK);
					//g.fillRect(1+Centerx*80,50+Centery*80,80,80);
			
			//==========================================================================
			//���촬                                     
                              
			 for (int n=0 ;n<RedPosyDT2.length;n++){
				// g.setColor(Color.BLACK);
				// g.fillRect(1+Centerx*80,50+Centery*80,80,80);
				 g.drawImage(Heidong,1+Centerx*80,50+Centery*80,80,80, this);
			 
                    if(n==Seled && TurnS==11) {
                    	 //g.setColor(Color.YELLOW);
     			        //g.fillRect(1+RedPosxDT2[Seled]*80,50+RedPosyDT2[Seled]*80,80,80);
                    	g.drawImage(RedSel, 1+RedPosxDT2[Seled]*80,50+RedPosyDT2[Seled]*80,80,80, this);
                    }else {
				 // g.setColor(Color.RED);
                 // g.fillRect(1+RedPosxDT2[n]*80,50+RedPosyDT2[n]*80,80,80);              
                    	 g.drawImage(RedShip, 1+RedPosxDT2[n]*80,50+RedPosyDT2[n]*80,80,80, this);       
                    } 
                           }

                          //������
                                      for (int n=0 ;n<BluePosxDT2.length;n++){
                                           // g.setColor(Color.BLACK);
                                           // g.fillRect(1+Centerx*80,50+Centery*80,80,80);
                                    	  g.drawImage(Heidong,1+Centerx*80,50+Centery*80,80,80, this);
                           
                                    if (TurnS ==22 && n==Seled ){

                                    // g.setColor(Color.darkGray);
			                        // g.fillRect(1+BluePosxDT2[n]*80,50+BluePosyDT2[n]*80,80,80);
			                         g.drawImage(BlueSel, 1+BluePosxDT2[n]*80,50+BluePosyDT2[n]*80,80,80, this);
                                  
                               }else {
                            	   
                            	  // g.setColor(Color.BLUE);
                                  // g.fillRect(1+BluePosxDT2[n]*80,50+BluePosyDT2[n]*80,80,80);
                                   g.drawImage(BlueShip, 1+BluePosxDT2[n]*80,50+BluePosyDT2[n]*80,80,80, this);
                            	   
                               }
                        

                       
                                   
                           }
                              //=================================================================================
                                      g.drawString("X:"+Integer.toString(Currentx),400, 40);
                                      g.drawString("Y:"+Integer.toString(Currenty),450, 40);
                                      
			
			}
			
		
			
				
				if(DtLevel==3) {
					
			         Centerx=4;
                     Centery=4;
				              //����ͼ
                     g.drawImage(BackImg2,1,50,720,720, this);
					
                     g.drawImage(Heidong,1+Centerx*80,50+Centery*80,80,80, this);
			//==========================================================================
			//���촬                                     
                              
			 for (int n=0 ;n<RedPosyDT3.length;n++){
				 //g.setColor(Color.BLACK);
				 //g.fillRect(1+Centerx*80,50+Centery*80,80,80);
	            
			 
                    if(n==Seled && TurnS==11) {
                    	// g.setColor(Color.YELLOW);
     			        //g.fillRect(1+RedPosxDT3[Seled]*80,50+RedPosyDT3[Seled]*80,80,80);
                    	g.drawImage(RedSel, 1+RedPosxDT3[Seled]*80,50+RedPosyDT3[Seled]*80,80,80, this);
                    }else {
				 // g.setColor(Color.RED);
                 // g.fillRect(1+RedPosxDT3[n]*80,50+RedPosyDT3[n]*80,80,80);              
                    	g.drawImage(RedShip, 1+RedPosxDT3[n]*80,50+RedPosyDT3[n]*80,80,80, this);       
                    } 
                           }

                          //������
                                      for (int n=0 ;n<BluePosxDT3.length;n++){
                                          //  g.setColor(Color.BLACK);
                                          //  g.fillRect(1+Centerx*80,50+Centery*80,80,80);
                        		         
                           
                                    if (TurnS ==22 && n==Seled ){

                                     //g.setColor(Color.darkGray);
			                         //g.fillRect(1+BluePosxDT3[n]*80,50+BluePosyDT3[n]*80,80,80);
                                    	 g.drawImage(BlueSel, 1+BluePosxDT3[n]*80,50+BluePosyDT3[n]*80,80,80, this);
                                  
                               }else {
                            	   
                            	  // g.setColor(Color.BLUE);
                                   //g.fillRect(1+BluePosxDT3[n]*80,50+BluePosyDT3[n]*80,80,80);
                                   g.drawImage(BlueShip, 1+BluePosxDT3[n]*80,50+BluePosyDT3[n]*80,80,80, this);
                            	   
                               }
                        

                       
                                   
                           }
                              //=================================================================================
                                      g.drawString("X:"+Integer.toString(Currentx),500, 40);
                                      g.drawString("Y:"+Integer.toString(Currenty),550, 40);
                                      
			
					

			
                         }
			
			
		}
		
		public void keyTyped(KeyEvent e)
		{  // ���ַ�����ĺ���
		}
		public void keyPressed(KeyEvent e) 
		{  
                        if(DtLevel==1){
                        	       WinScore=2;
                                   BottomMax=4;
                                   RightMax=4; 
                                   Centerx=2;
                                   Centery=2;
                         }
                        
                        if(DtLevel==2){
                 	       WinScore=3;
                            BottomMax=6;
                            RightMax=6; 
                            Centerx=3;
                            Centery=3;
                        }
                        
                        
                        if(DtLevel==3){
                 	       WinScore=4;
                            BottomMax=8;
                            RightMax=8; 
                            Centerx=4;
                            Centery=4;
                        }
                                
			if(e.getKeyCode()==KeyEvent.VK_DOWN  )  //��
			{    
				
				//**********************************************************************
                //ȡ��ǰ���Ʒɴ�������    
       	   if(TurnS==11) {
       		   switch(DtLevel) {
       		   case 1:
       			   Currentx=RedPosxDT1[Seled];
                      Currenty=RedPosyDT1[Seled];
       			   break;
       		   case 2:
       			   Currentx=RedPosxDT2[Seled];
                      Currenty=RedPosyDT2[Seled];
       			   break;
       		   case 3:
       			   Currentx=RedPosxDT3[Seled];
                      Currenty=RedPosyDT3[Seled];
       			   break;
       		   }
		              
			      }else{
			    	  
  			    	switch(DtLevel) {
	         		   case 1:
	         			    Currentx=BluePosxDT1[Seled];
	   	                    Currenty=BluePosyDT1[Seled];
	         			   break;
	         		   case 2:
	         			    Currentx=BluePosxDT2[Seled];
	   	                    Currenty=BluePosyDT2[Seled];
	         			   break;
	         		   case 3:
	         			    Currentx=BluePosxDT3[Seled];
	   	                    Currenty=BluePosyDT3[Seled];
	         			   break;
        		   }
  			    	  
			    	  
			    	  
			    	   
			      }
				
	
                                    if(TurnS==11)
                                  {
                                 	
                                            if(Currenty<BottomMax ){
                                            	
                                            	switch(DtLevel) {
                                            	case 1:
                                            		 while( DT1[Currentx][Currenty+1]==0){
                                                         
                                                         DT1[Currentx][Currenty+1]=1;
                                                         DT1[Currentx][Currenty]=0;
                                                         Currenty++;
                                                         RedPosyDT1[Seled]=Currenty;
                                                            if(Currenty<BottomMax) {

                                                            }else {break;}
                                                   } 
                                                     
                                                     if(Currenty<BottomMax) {
                                                         if( DT1[Currentx][Currenty+1]==9){                                                         
                                                             DT1[Currentx][Currenty]=0;
                                                             Currenty++;
                                                             RedPosyDT1[Seled]=Currenty;
                                                             
                                                         }
                                                }
                                                     
                                                     TurnS=22;
                                            		
                                            		break;
                                            	case 2:
                                                       while( DT2[Currentx][Currenty+1]==0){
                                                         
                                                         DT2[Currentx][Currenty+1]=1;
                                                         DT2[Currentx][Currenty]=0;
                                                         Currenty++;
                                                         RedPosyDT2[Seled]=Currenty;
                                                            if(Currenty<BottomMax) {

                                                            }else {break;}
                                                   } 
                                                     
                                                     if(Currenty<BottomMax) {
                                                         if( DT2[Currentx][Currenty+1]==9){                                                         
                                                             DT2[Currentx][Currenty]=0;
                                                             Currenty++;
                                                             RedPosyDT2[Seled]=Currenty;
                                                             
                                                         }
                                                }
                                                     
                                                     TurnS=22;
                                            		
                                            		break;
                                            	case 3:
                                                       while( DT3[Currentx][Currenty+1]==0){
                                                         
                                                         DT3[Currentx][Currenty+1]=1;
                                                         DT3[Currentx][Currenty]=0;
                                                         Currenty++;
                                                         RedPosyDT3[Seled]=Currenty;
                                                            if(Currenty<BottomMax) {

                                                            }else {break;}
                                                   } 
                                                     
                                                     if(Currenty<BottomMax) {
                                                         if( DT3[Currentx][Currenty+1]==9){                                                         
                                                             DT3[Currentx][Currenty]=0;
                                                             Currenty++;
                                                             RedPosyDT3[Seled]=Currenty;
                                                             
                                                         }
                                                }
                                                     
                                                     TurnS=22;
                                            		
                                            		break;
                                            	
                                            	}
                                            	
                                          
                                                 
                                                 
                                                 
                                            }

                                 }else{
                                	 

		                                       
		                                	 
		                                	 
		                                	 if(Currenty<BottomMax ){
			                                     	
		                                		 switch(DtLevel){
		                                		      
		                                		 case 1:
		                                			 
			                                         while( DT1[Currentx][Currenty+1]==0){
			                                                 
			                                                 DT1[Currentx][Currenty+1]=1;
			                                                 DT1[Currentx][Currenty]=0;
			                                                 Currenty++;
			                                                 BluePosyDT1[Seled]=Currenty;
			                                                 
			                                                  if(Currenty<BottomMax) {

			                                                  }else {break;}
			                                           } 
			                                         
			                                         
			                                         
			                                         if(Currenty<BottomMax) {
		                                                 if( DT1[Currentx][Currenty+1]==9){
				                                             
				                                             
				                                             DT1[Currentx][Currenty]=0;
				                                             Currenty++;
				                                             BluePosyDT1[Seled]=Currenty;
				                                            
				                                         }
	                                              }
			                                         
			                                         
			                                         
			                                         
			                                         
			                                         TurnS=11;
		                                			  
		                                			 break;
		                                		 case 2:
		                                			 
		                                			 
			                                         while( DT2[Currentx][Currenty+1]==0){
			                                                 
			                                                 DT2[Currentx][Currenty+1]=1;
			                                                 DT2[Currentx][Currenty]=0;
			                                                 Currenty++;
			                                                 BluePosyDT2[Seled]=Currenty;
			                                                 
			                                                  if(Currenty<BottomMax) {

			                                                  }else {break;}
			                                           } 
			                                         
			                                         
			                                         
			                                         if(Currenty<BottomMax) {
		                                                 if( DT2[Currentx][Currenty+1]==9){
				                                             
				                                             
				                                             DT2[Currentx][Currenty]=0;
				                                             Currenty++;
				                                             BluePosyDT2[Seled]=Currenty;
				                                            
				                                         }
	                                              }
			                                         
			                                         
			                                         
			                                         
			                                         
			                                         TurnS=11;
		                                			 break;
		                                		 case 3:
		                                			 
		                                			 
			                                         while( DT3[Currentx][Currenty+1]==0){
			                                                 
			                                                 DT3[Currentx][Currenty+1]=1;
			                                                 DT3[Currentx][Currenty]=0;
			                                                 Currenty++;
			                                                 BluePosyDT3[Seled]=Currenty;
			                                                 
			                                                  if(Currenty<BottomMax) {

			                                                  }else {break;}
			                                           } 
			                                         
			                                         
			                                         
			                                         if(Currenty<BottomMax) {
		                                                 if( DT3[Currentx][Currenty+1]==9){
				                                             
				                                             
				                                             DT3[Currentx][Currenty]=0;
				                                             Currenty++;
				                                             BluePosyDT3[Seled]=Currenty;
				                                            
				                                         }
	                                              }
			                                         
			                                         
			                                         
			                                         
			                                         
			                                         TurnS=11;
		                                			 break;
		                                		 
		                                		 
		                                		 }
		                                	
                                                 }

                                       }











			}
			else if(e.getKeyCode()==KeyEvent.VK_UP)   //��
			{
				//***********************************************
                //ȡ��ǰ���Ʒɴ�������    
       	   if(TurnS==11) {
       		   switch(DtLevel) {
       		   case 1:
       			   Currentx=RedPosxDT1[Seled];
                      Currenty=RedPosyDT1[Seled];
       			   break;
       		   case 2:
       			   Currentx=RedPosxDT2[Seled];
                      Currenty=RedPosyDT2[Seled];
       			   break;
       		   case 3:
       			   Currentx=RedPosxDT3[Seled];
                      Currenty=RedPosyDT3[Seled];
       			   break;
       		   }
		              
			      }else{
			    	  
  			    	switch(DtLevel) {
	         		   case 1:
	         			    Currentx=BluePosxDT1[Seled];
	   	                    Currenty=BluePosyDT1[Seled];
	         			   break;
	         		   case 2:
	         			    Currentx=BluePosxDT2[Seled];
	   	                    Currenty=BluePosyDT2[Seled];
	         			   break;
	         		   case 3:
	         			    Currentx=BluePosxDT3[Seled];
	   	                    Currenty=BluePosyDT3[Seled];
	         			   break;
        		   }
  			    	  
			    	  
			    	  
			    	   
			      }
				
			
							     if(TurnS==11)
				                 {
				    	
				                           if(Currenty>0 ){
				                           	
                                                 switch(DtLevel) {
                                                       case 1:
                                                    	   
                                                           while( DT1[Currentx][Currenty-1]==0){
           			                                        
           			                                        DT1[Currentx][Currenty-1]=1;
           			                                        DT1[Currentx][Currenty]=0;
           			                                        Currenty--;
           			                                        RedPosyDT1[Seled]=Currenty;
           			                                           if(Currenty>0) {

           			                                           }else {break;}
           			                                        
           			                                  }  
           				                                
           				                                
           				                                
           				                                
           				                                if(Currenty>0) {
           			                                        if( DT1[Currentx][Currenty-1]==9){
           					                                    
           					                                    
           					                                    DT1[Currentx][Currenty]=0;
           					                                    Currenty--;
           					                                    RedPosyDT1[Seled]=Currenty;
           					                                    
           					                                }
           	                                           }
           				                                
           				                                
           				                                TurnS=22;  
                                                	        break;
                                                       case 2:
                                                    	   
                                                           while( DT2[Currentx][Currenty-1]==0){
           			                                        
           			                                        DT2[Currentx][Currenty-1]=1;
           			                                        DT2[Currentx][Currenty]=0;
           			                                        Currenty--;
           			                                        RedPosyDT2[Seled]=Currenty;
           			                                           if(Currenty>0) {

           			                                           }else {break;}
           			                                        
           			                                  }  
           				                                
           				                                
           				                                
           				                                
           				                                if(Currenty>0) {
           			                                        if( DT2[Currentx][Currenty-1]==9){
           					                                    
           					                                    
           					                                    DT2[Currentx][Currenty]=0;
           					                                    Currenty--;
           					                                    RedPosyDT2[Seled]=Currenty;
           					                                    
           					                                }
           	                                           }
           				                                
           				                                
           				                                TurnS=22;  
                                                    	    break;
                                                       case 3:
                                                    	   
                                                           while( DT3[Currentx][Currenty-1]==0){
           			                                        
           			                                        DT3[Currentx][Currenty-1]=1;
           			                                        DT3[Currentx][Currenty]=0;
           			                                        Currenty--;
           			                                        RedPosyDT3[Seled]=Currenty;
           			                                           if(Currenty>0) {

           			                                           }else {break;}
           			                                        
           			                                  }  
           				                                
           				                                
           				                                
           				                                
           				                                if(Currenty>0) {
           			                                        if( DT3[Currentx][Currenty-1]==9){
           					                                    
           					                                    
           					                                    DT3[Currentx][Currenty]=0;
           					                                    Currenty--;
           					                                    RedPosyDT3[Seled]=Currenty;
           					                                    
           					                                }
           	                                           }
           				                                
           				                                
           				                                TurnS=22;  
                                                    	    break;
                                                 
                                                 
                                                 
                                                 }
//				                                
				                                
				                         
				                                
				                                
				                           }
				
				                }else{
				                	 
				                       	 if(Currenty>0 ){
				                            	

				                       		      switch(DtLevel) {
					                       		      case 1:

								                       		 
								                       		while( DT1[Currentx][Currenty-1]==0){
				                                                
				                                                DT1[Currentx][Currenty-1]=1;
				                                                DT1[Currentx][Currenty]=0;
				                                                Currenty--;
				                                                BluePosyDT1[Seled]=Currenty;
				                                                if(Currenty>0) {

				                                                }else {break;}
				                                                 
				                                          }
								                       	 if(Currenty>0) {
				                                                if( DT1[Currentx][Currenty-1]==9){
						                                            
						                                            
						                                            DT1[Currentx][Currenty]=0;
						                                            Currenty--;
						                                            BluePosyDT1[Seled]=Currenty;
						                                           
		                                                          }
		                                                }
								                       	 TurnS=11;
					                       		    	   break;
					                       		      case 2:
					                       		    	  

								                       		 
								                       		while( DT2[Currentx][Currenty-1]==0){
				                                                
				                                                DT2[Currentx][Currenty-1]=1;
				                                                DT2[Currentx][Currenty]=0;
				                                                Currenty--;
				                                                BluePosyDT2[Seled]=Currenty;
				                                                if(Currenty>0) {

				                                                }else {break;}
				                                                 
				                                          }
								                       	 if(Currenty>0) {
				                                                if( DT2[Currentx][Currenty-1]==9){
						                                            
						                                            
						                                            DT2[Currentx][Currenty]=0;
						                                            Currenty--;
						                                            BluePosyDT2[Seled]=Currenty;
						                                           
		                                                          }
		                                                }
								                       	 TurnS=11;
					                       		    	    break;
					                       		      case 3:
					                       		      

							                       		 
							                       		while( DT3[Currentx][Currenty-1]==0){
			                                                
			                                                DT3[Currentx][Currenty-1]=1;
			                                                DT3[Currentx][Currenty]=0;
			                                                Currenty--;
			                                                BluePosyDT3[Seled]=Currenty;
			                                                if(Currenty>0) {

			                                                }else {break;}
			                                                 
			                                          }
							                       	 if(Currenty>0) {
			                                                if( DT3[Currentx][Currenty-1]==9){
					                                            
					                                            
					                                            DT3[Currentx][Currenty]=0;
					                                            Currenty--;
					                                            BluePosyDT3[Seled]=Currenty;
					                                           
	                                                          }
	                                                }
							                       	 TurnS=11;
					                       		            break;			                       		      
					                       		      
				                       		       }
				                       		 
				                       		 
				                              }
				                              
				
				                     }
				
				
				




                        
			}                                                                                                                             
			else if(e.getKeyCode()==KeyEvent.VK_LEFT ) //��
			{
				
				//**************************************************
                //ȡ��ǰ���Ʒɴ�������    
       	   if(TurnS==11) {
       		   switch(DtLevel) {
       		   case 1:
       			   Currentx=RedPosxDT1[Seled];
                      Currenty=RedPosyDT1[Seled];
       			   break;
       		   case 2:
       			   Currentx=RedPosxDT2[Seled];
                      Currenty=RedPosyDT2[Seled];
       			   break;
       		   case 3:
       			   Currentx=RedPosxDT3[Seled];
                      Currenty=RedPosyDT3[Seled];
       			   break;
       		   }
		              
			      }else{
			    	  
  			    	switch(DtLevel) {
	         		   case 1:
	         			    Currentx=BluePosxDT1[Seled];
	   	                    Currenty=BluePosyDT1[Seled];
	         			   break;
	         		   case 2:
	         			    Currentx=BluePosxDT2[Seled];
	   	                    Currenty=BluePosyDT2[Seled];
	         			   break;
	         		   case 3:
	         			    Currentx=BluePosxDT3[Seled];
	   	                    Currenty=BluePosyDT3[Seled];
	         			   break;
        		   }
  			    	  
			    	  
			    	  
			    	   
			      }
				//******************************************************
				
//				if(TurnS==11) {
//		            Currentx=RedPosxDT1[Seled];
//                    Currenty=RedPosyDT1[Seled];
//			      }else{
//			    	  Currentx=BluePosxDT1[Seled];
//	                    Currenty=BluePosyDT1[Seled];
//			      }
				// JOptionPane.showMessageDialog(null,"X:"+Integer.toString(Currentx)+"  y:"+Integer.toString(Currenty));
                                if(TurnS==11){
                                	 
		                                  if(Currentx>0){

		                                	     switch(DtLevel){
								                        
								                        case 1:
								                       	  
						                                	  while(DT1[Currentx-1][Currenty]==0){
											                         
							                                         DT1[Currentx-1][Currenty]=1;
							                                         DT1[Currentx][Currenty]=0;
							                                         Currentx--;
							                                         RedPosxDT1[Seled]=Currentx;
							                                         
							                                               if(Currentx>0) {
									                        
							                                               }else {break;}
							                                         
							                                   } 
						                                	  if(Currentx>0) {
							                                         if (  DT1[Currentx-1][Currenty]==9){
												                         
											                        	 
									                                        
								                                         DT1[Currentx][Currenty]=0;
								                                         Currentx--;
								                                         RedPosxDT1[Seled]=Currentx;
								                                         
										                              }
							                                         
				                                               }
						                                	  TurnS=22;
								                        	break;
								                        case 2:
								                       	  
						                                	  while(DT2[Currentx-1][Currenty]==0){
											                         
							                                         DT2[Currentx-1][Currenty]=1;
							                                         DT2[Currentx][Currenty]=0;
							                                         Currentx--;
							                                         RedPosxDT2[Seled]=Currentx;
							                                         
							                                               if(Currentx>0) {
									                        
							                                               }else {break;}
							                                         
							                                   } 
						                                	  if(Currentx>0) {
							                                         if (  DT2[Currentx-1][Currenty]==9){
												                         
											                        	 
									                                        
								                                         DT2[Currentx][Currenty]=0;
								                                         Currentx--;
								                                         RedPosxDT2[Seled]=Currentx;
								                                         
										                              }
							                                         
				                                               }
						                                	  TurnS=22;
								                        	break;
								                        case 3:
								                       	  
						                                	  while(DT3[Currentx-1][Currenty]==0){
											                         
							                                         DT3[Currentx-1][Currenty]=1;
							                                         DT3[Currentx][Currenty]=0;
							                                         Currentx--;
							                                         RedPosxDT3[Seled]=Currentx;
							                                         
							                                               if(Currentx>0) {
									                        
							                                               }else {break;}
							                                         
							                                   } 
						                                	  if(Currentx>0) {
							                                         if (  DT3[Currentx-1][Currenty]==9){
												                         
											                        	 
									                                        
								                                         DT3[Currentx][Currenty]=0;
								                                         Currentx--;
								                                         RedPosxDT3[Seled]=Currentx;
								                                         
										                              }
							                                         
				                                               }
						                                	  TurnS=22;
								                        	break;
								                        
			                        
								                        } 
		                                	  
							                               
		                                	  
		                                	  
		                                	  
		                                	  
				                                	     
				                                   }

                                }else{
                                	 
                                
				                                	 if(Currentx>0   ){

										                     switch(DtLevel) {
										                     
										                     case 1:
										                		 
						                                		 while( DT1[Currentx-1][Currenty]==0){
											                         
							                                         DT1[Currentx-1][Currenty]=1;
							                                         DT1[Currentx][Currenty]=0;
							                                         Currentx--;
							                                         BluePosxDT1[Seled]=Currentx;
							                                         
							                                            if(Currentx>0) {
							                                         
//										                                       
										                                         
							                                            }else {break;}
							                                         
							                                      } 
						                                		 
						                                		 
						                                		 if(Currentx>0) {
							                                         
							                                         if (  DT1[Currentx-1][Currenty]==9){
												                         
											                        	 
									                                        
								                                         DT1[Currentx][Currenty]=0;
								                                         Currentx--;
								                                         BluePosxDT1[Seled]=Currentx;
								                                         
										                               }
							                                         
				                                            }
						                                		 
						                                		 TurnS=11;
										                    	 break;
										                     case 2:
										                		 
						                                		 while( DT2[Currentx-1][Currenty]==0){
											                         
							                                         DT2[Currentx-1][Currenty]=1;
							                                         DT2[Currentx][Currenty]=0;
							                                         Currentx--;
							                                         BluePosxDT2[Seled]=Currentx;
							                                         
							                                            if(Currentx>0) {
							                                         
//										                                       
										                                         
							                                            }else {break;}
							                                         
							                                      } 
						                                		 
						                                		 
						                                		 if(Currentx>0) {
							                                         
							                                         if (  DT2[Currentx-1][Currenty]==9){
												                         
											                        	 
									                                        
								                                         DT2[Currentx][Currenty]=0;
								                                         Currentx--;
								                                         BluePosxDT2[Seled]=Currentx;
								                                         
										                               }
							                                         
				                                            }
						                                		 
						                                		 TurnS=11;
										                    	 break;
										                     case 3:
										                		 
						                                		 while( DT3[Currentx-1][Currenty]==0){
											                         
							                                         DT3[Currentx-1][Currenty]=1;
							                                         DT3[Currentx][Currenty]=0;
							                                         Currentx--;
							                                         BluePosxDT3[Seled]=Currentx;
							                                         
							                                            if(Currentx>0) {
							                                         
//										                                       
										                                         
							                                            }else {break;}
							                                         
							                                      } 
						                                		 
						                                		 
						                                		 if(Currentx>0) {
							                                         
							                                         if (  DT3[Currentx-1][Currenty]==9){
												                         
											                        	 
									                                        
								                                         DT3[Currentx][Currenty]=0;
								                                         Currentx--;
								                                         BluePosxDT3[Seled]=Currentx;
								                                         
										                               }
							                                         
				                                            }
						                                		 
						                                		 TurnS=11;
										                    	 break;
										               
										                     }    
						                                	     
				                                
				                		 
				                                		 
						                                   }    


                                }
			}
			else if(e.getKeyCode()==KeyEvent.VK_RIGHT) //��
			{    
				  
				
				//*******************************************************
                //ȡ��ǰ���Ʒɴ�������    
       	   if(TurnS==11) {
       		   switch(DtLevel) {
       		   case 1:
       			   Currentx=RedPosxDT1[Seled];
                      Currenty=RedPosyDT1[Seled];
       			   break;
       		   case 2:
       			   Currentx=RedPosxDT2[Seled];
                      Currenty=RedPosyDT2[Seled];
       			   break;
       		   case 3:
       			   Currentx=RedPosxDT3[Seled];
                      Currenty=RedPosyDT3[Seled];
       			   break;
       		   }
		              
			      }else{
			    	  
  			    	switch(DtLevel) {
	         		   case 1:
	         			    Currentx=BluePosxDT1[Seled];
	   	                    Currenty=BluePosyDT1[Seled];
	         			   break;
	         		   case 2:
	         			    Currentx=BluePosxDT2[Seled];
	   	                    Currenty=BluePosyDT2[Seled];
	         			   break;
	         		   case 3:
	         			    Currentx=BluePosxDT3[Seled];
	   	                    Currenty=BluePosyDT3[Seled];
	         			   break;
        		   }
  			    	  
			    	  
			    	  
			    	   
			      }
				//**********************************************************
				
				
				
//				if(TurnS==11) {
//		            Currentx=RedPosxDT1[Seled];
//                    Currenty=RedPosyDT1[Seled];
//			      }else{
//			    	  Currentx=BluePosxDT1[Seled];
//	                    Currenty=BluePosyDT1[Seled];
//			      }
				// JOptionPane.showMessageDialog(null,"X:"+Integer.toString(Currentx)+"  y:"+Integer.toString(Currenty));
		        //JOptionPane.showMessageDialog(null,"y:"+Integer.toString(Currenty));
				 //JOptionPane.showMessageDialog(null,"t:"+Integer.toString(TurnS));
                                if(TurnS==11){
                                	
	                                        if(Currentx<RightMax ){
					                              switch(DtLevel) {
							                              case 1:
							                                 	while(DT1[Currentx+1][Currenty]==0){
									                                 
									                                 DT1[Currentx+1][Currenty]=1;
									                                 DT1[Currentx][Currenty]=0;
									                                 Currentx++;
									                                 RedPosxDT1[Seled]=Currentx;
									                                 
									                                 
									                                 
									                                 if(Currentx<RightMax ) {
//                                                                     
									                                 }else {break;}
                                                                     
									                            } 
                                       	
					                                        	
					                                        	
					                                        	 if(Currentx<RightMax ) {
                                                                    if(DT1[Currentx+1][Currenty]==9){
						                                    	    
						                                    	    	 
										                                 
										                                 DT1[Currentx][Currenty]=0;
										                                 Currentx++;
										                                 RedPosxDT1[Seled]=Currentx;
										                                 
						                                    	    
									                                 
									                                      }
								                                 }
					                                        	TurnS=22;
							                            	  break;
							                              case 2:
							                                 	while(DT2[Currentx+1][Currenty]==0){
									                                 
									                                 DT2[Currentx+1][Currenty]=1;
									                                 DT2[Currentx][Currenty]=0;
									                                 Currentx++;
									                                 RedPosxDT2[Seled]=Currentx;
									                                 
									                                 
									                                 
									                                 if(Currentx<RightMax ) {
//                                                                     
									                                 }else {break;}
                                                                     
									                            } 
                                       	
					                                        	
					                                        	
					                                        	 if(Currentx<RightMax ) {
                                                                    if(DT2[Currentx+1][Currenty]==9){
						                                    	    
						                                    	    	 
										                                 
										                                 DT2[Currentx][Currenty]=0;
										                                 Currentx++;
										                                 RedPosxDT2[Seled]=Currentx;
										                                 
						                                    	    
									                                 
									                                      }
								                                 }
					                                        	TurnS=22;
							                            	  break;
							                              case 3:
							                                 	while(DT3[Currentx+1][Currenty]==0){
									                                 
									                                 DT3[Currentx+1][Currenty]=1;
									                                 DT3[Currentx][Currenty]=0;
									                                 Currentx++;
									                                 RedPosxDT3[Seled]=Currentx;
									                                 
									                                 
									                                 
									                                 if(Currentx<RightMax ) {
//                                                                     
									                                 }else {break;}
                                                                     
									                            } 
                                       	
					                                        	
					                                        	
					                                        	 if(Currentx<RightMax ) {
                                                                    if(DT3[Currentx+1][Currenty]==9){
						                                    	    
						                                    	    	 
										                                 
										                                 DT3[Currentx][Currenty]=0;
										                                 Currentx++;
										                                 RedPosxDT3[Seled]=Currentx;
										                                 
						                                    	    
									                                 
									                                      }
								                                 }
					                                        	TurnS=22;
							                            	  break;
					                              
					                              }

	                                        	
						                         
	                                        	
	                                        	
	                                        	
	                                        	
	                                        	
	                                         }

                                 }else{
                                	
                                	 
                                	      if(Currentx<RightMax ){
                     					
                                	    	  		switch(DtLevel) {
	                                	    	  		case 1:
	                                          	    	  while(DT1[Currentx+1][Currenty]==0){
								                                 
								                                 DT1[Currentx+1][Currenty]=1;
								                                 DT1[Currentx][Currenty]=0;
								                                 Currentx++;
								                                 BluePosxDT1[Seled]=Currentx;
								                                 if(Currentx<RightMax ){
//										                                
										                                 
								                                 }else {break;}
                 	    	  
								                                 
								                                 
								                                 
								                            }
			                                	    	  if(Currentx<RightMax ){
								                                 if(DT1[Currentx+1][Currenty]==9){											                                 
									                                 DT1[Currentx][Currenty]=0;
									                                 Currentx++;
									                                 BluePosxDT1[Seled]=Currentx;
									                                 							                                    	    
								                                 
								                                 }
								                                 
						                                 }
			                                	    	  TurnS=11;
	                                	    	  			break;
	                                	    	  		case 2:
	                                          	    	  while(DT2[Currentx+1][Currenty]==0){
								                                 
								                                 DT2[Currentx+1][Currenty]=1;
								                                 DT2[Currentx][Currenty]=0;
								                                 Currentx++;
								                                 BluePosxDT2[Seled]=Currentx;
								                                 if(Currentx<RightMax ){
//										                                
										                                 
								                                 }else {break;}
                 	    	  
								                                 
								                                 
								                                 
								                            }
			                                	    	  if(Currentx<RightMax ){
								                                 if(DT2[Currentx+1][Currenty]==9){											                                 
									                                 DT2[Currentx][Currenty]=0;
									                                 Currentx++;
									                                 BluePosxDT2[Seled]=Currentx;
									                                 							                                    	    
								                                 
								                                 }
								                                 
						                                 }
			                                	    	  TurnS=11;
	                                	    	  			break;
	                                	    	  		case 3:
	                                          	    	  while(DT3[Currentx+1][Currenty]==0){
								                                 
								                                 DT3[Currentx+1][Currenty]=1;
								                                 DT3[Currentx][Currenty]=0;
								                                 Currentx++;
								                                 BluePosxDT3[Seled]=Currentx;
								                                 if(Currentx<RightMax ){
//										                                
										                                 
								                                 }else {break;}
                 	    	  
								                                 
								                                 
								                                 
								                            }
			                                	    	  if(Currentx<RightMax ){
								                                 if(DT3[Currentx+1][Currenty]==9){											                                 
									                                 DT3[Currentx][Currenty]=0;
									                                 Currentx++;
									                                 BluePosxDT3[Seled]=Currentx;
									                                 							                                    	    
								                                 
								                                 }
								                                 
						                                 }
			                                	    	  TurnS=11;
	                                	    	  			break;
                                	    	  		
                                	    	  		}

                                	    	  
						                
                                	    	  
                                	    	  
                                	    	  
                                           }


                                 }
			}else if(e.getKeyCode()==KeyEvent.VK_SPACE) //�ո�ѡ��
			{    
				 switch(DtLevel) {
                 case 1:
                	  if(TurnS==11){  //�ú���
                          
	                       
                          //ѡ�б仯
                           if (Seled<(RedPosxDT1.length-1)){
                                
                               
                                 Seled=Seled+1;
                               
                               
                           }else{
                                 Seled=0;
                           }

                    Currentx=RedPosxDT1[Seled];
                    Currenty=RedPosyDT1[Seled];
                 
                    //this.repaint();
                 }else{
                           //��
                   

	                         //ѡ�б仯
	                           if (Seled<BluePosxDT1.length-1){
	                                 Seled=Seled+1;
	                           }else {
	                                 Seled=0;
	                           }
                 
	                           Currentx=BluePosxDT1[Seled];
	                            Currenty=BluePosyDT1[Seled];  
	                            this.repaint();
	                           
                 } 
                 	break;
                 case 2:
                	  if(TurnS==11){  //�ú���
                          
	                       
                          //ѡ�б仯
                           if (Seled<(RedPosxDT2.length-1)){
                                
                               
                                 Seled=Seled+1;
                               
                               
                           }else{
                                 Seled=0;
                           }

                    Currentx=RedPosxDT2[Seled];
                    Currenty=RedPosyDT2[Seled];
                 
                    //this.repaint();
                 }else{
                           //��
                   

	                         //ѡ�б仯
	                           if (Seled<BluePosxDT2.length-1){
	                                 Seled=Seled+1;
	                           }else {
	                                 Seled=0;
	                           }
                 
	                           Currentx=BluePosxDT2[Seled];
	                            Currenty=BluePosyDT2[Seled];  
	                            this.repaint();
	                           
                 } 
                 	break;
                 case 3:
                	  if(TurnS==11){  //�ú���
                          
	                       
                          //ѡ�б仯
                           if (Seled<(RedPosxDT3.length-1)){
                                
                               
                                 Seled=Seled+1;
                               
                               
                           }else{
                                 Seled=0;
                           }

                    Currentx=RedPosxDT3[Seled];
                    Currenty=RedPosyDT3[Seled];
                 
                    //this.repaint();
                 }else{
                           //��
                   

	                         //ѡ�б仯
	                           if (Seled<BluePosxDT3.length-1){
	                                 Seled=Seled+1;
	                           }else {
	                                 Seled=0;
	                           }
                 
	                           Currentx=BluePosxDT3[Seled];
	                            Currenty=BluePosyDT3[Seled];  
	                            this.repaint();
	                           
                 } 
                 	break;
             
                  }
                           
                           
                        
			}
                      
              
                   switch(DtLevel) {
			                   case 1:
			                	   if(Seled<0||Seled>RedPosxDT1.length-1) {Seled=0;}
			                	   if(Seled<0||Seled>RedPosyDT1.length-1) {Seled=0;}
			                	   if(RedPosxDT1[Seled]==Centerx && RedPosyDT1[Seled]==Centery){ 
			                           
		                                 Redscore++;

		                               //�����һ��Ԫ�����ָ����Ԫ��
		 
		                               RedPosxDT1[Seled] = RedPosxDT1[RedPosxDT1.length-1];
		 
		                              //��������
		 
		                                 RedPosxDT1 = Arrays.copyOf(RedPosxDT1, RedPosxDT1.length-1);

		                              //�����һ��Ԫ�����ָ����Ԫ��
		 
		                                  RedPosyDT1[Seled] = RedPosyDT1[RedPosyDT1.length-1];
		 
		                               //��������
		 
		                                   RedPosyDT1 = Arrays.copyOf(RedPosyDT1, RedPosyDT1.length-1);
		                               }
		                             
		                             
		                             
		                             
		                             
			                	   if(Seled<0||Seled>BluePosxDT1.length-1) {Seled=0;}
			                	   if(Seled<0||Seled>BluePosyDT1.length-1) {Seled=0;}
		                             if(BluePosxDT1[Seled]==Centerx && BluePosyDT1[Seled]==Centery){ 
		                                 
		                                 Bluescore++;

		                               //�����һ��Ԫ�����ָ����Ԫ��
		 
		                               BluePosxDT1[Seled] = BluePosxDT1[BluePosxDT1.length-1];
		 
		                              //��������
		 
		                                 BluePosxDT1 = Arrays.copyOf(BluePosxDT1, BluePosxDT1.length-1);

		                              //�����һ��Ԫ�����ָ����Ԫ��
		 
		                                  BluePosyDT1[Seled] = BluePosyDT1[BluePosyDT1.length-1];
		 
		                               //��������
		 
		                                   BluePosyDT1 = Arrays.copyOf(BluePosyDT1, BluePosyDT1.length-1);
		                               }
		                             
			                	   break;
			                   case 2:
			                	   if(Seled<0||Seled>RedPosxDT2.length-1) {Seled=0;}
			                	   if(Seled<0||Seled>RedPosyDT2.length-1) {Seled=0;}
			                	   if(RedPosxDT2[Seled]==Centerx && RedPosyDT2[Seled]==Centery){ 
			                           
		                                 Redscore++;

		                               //�����һ��Ԫ�����ָ����Ԫ��
		 
		                               RedPosxDT2[Seled] = RedPosxDT2[RedPosxDT2.length-1];
		 
		                              //��������
		 
		                                 RedPosxDT2 = Arrays.copyOf(RedPosxDT2, RedPosxDT2.length-1);

		                              //�����һ��Ԫ�����ָ����Ԫ��
		 
		                                  RedPosyDT2[Seled] = RedPosyDT2[RedPosyDT2.length-1];
		 
		                               //��������
		 
		                                   RedPosyDT2 = Arrays.copyOf(RedPosyDT2, RedPosyDT2.length-1);
		                               }
		                             
		                             
		                             
		                             
		                             
			                	   if(Seled<0||Seled>BluePosxDT2.length-1) {Seled=0;}
			                	   if(Seled<0||Seled>BluePosyDT2.length-1) {Seled=0;}
		                             if(BluePosxDT2[Seled]==Centerx && BluePosyDT2[Seled]==Centery){ 
		                                 
		                                 Bluescore++;

		                               //�����һ��Ԫ�����ָ����Ԫ��
		 
		                               BluePosxDT2[Seled] = BluePosxDT2[BluePosxDT2.length-1];
		 
		                              //��������
		 
		                                 BluePosxDT2 = Arrays.copyOf(BluePosxDT2, BluePosxDT2.length-1);

		                              //�����һ��Ԫ�����ָ����Ԫ��
		 
		                                  BluePosyDT2[Seled] = BluePosyDT2[BluePosyDT2.length-1];
		 
		                               //��������
		 
		                                   BluePosyDT2 = Arrays.copyOf(BluePosyDT2, BluePosyDT2.length-1);
		                               }
		                             
			                	    break;
			                   case 3:
			                	   if(Seled<0||Seled>RedPosxDT3.length-1) {Seled=0;}
			                	   if(Seled<0||Seled>RedPosyDT3.length-1) {Seled=0;}
			                	   if(RedPosxDT3[Seled]==Centerx && RedPosyDT3[Seled]==Centery){ 
			                           
		                                 Redscore++;

		                               //�����һ��Ԫ�����ָ����Ԫ��
		 
		                               RedPosxDT3[Seled] = RedPosxDT3[RedPosxDT3.length-1];
		 
		                              //��������
		 
		                                 RedPosxDT3 = Arrays.copyOf(RedPosxDT3, RedPosxDT3.length-1);

		                              //�����һ��Ԫ�����ָ����Ԫ��
		 
		                                  RedPosyDT3[Seled] = RedPosyDT3[RedPosyDT3.length-1];
		 
		                               //��������
		 
		                                   RedPosyDT3 = Arrays.copyOf(RedPosyDT3, RedPosyDT3.length-1);
		                               }
		                             
		                             
		                             
		                             
			                	   if(Seled<0||Seled>BluePosxDT3.length-1) {Seled=0;}
			                	   if(Seled<0||Seled>BluePosyDT3.length-1) {Seled=0;}
		                             
		                             if(BluePosxDT3[Seled]==Centerx && BluePosyDT3[Seled]==Centery){ 
		                                 
		                                 Bluescore++;

		                               //�����һ��Ԫ�����ָ����Ԫ��
		 
		                               BluePosxDT3[Seled] = BluePosxDT3[BluePosxDT3.length-1];
		 
		                              //��������
		 
		                                 BluePosxDT3 = Arrays.copyOf(BluePosxDT3, BluePosxDT3.length-1);

		                              //�����һ��Ԫ�����ָ����Ԫ��
		 
		                                  BluePosyDT3[Seled] = BluePosyDT3[BluePosyDT3.length-1];
		 
		                               //��������
		 
		                                   BluePosyDT3 = Arrays.copyOf(BluePosyDT3, BluePosyDT3.length-1);
		                               }
		                             
			                	    break;
                 
                   }
                      
                   
                            
                             
                             

                        
			            //  this.repaint();
                      if (Redscore==WinScore){  
                          JOptionPane.showMessageDialog(null,"Red victor");
                         Redscore=0;Bluescore=0;
                          init();
                          }
                       if (Bluescore==WinScore){  
                          JOptionPane.showMessageDialog(null,"Blue victor");
                         Bluescore=0;Redscore=0;
                          init();
                          }
                       this.repaint();
		}
	    public void keyReleased(KeyEvent e) 
	    {
		   //����̧��
		}  
		
		
		
		
		
		
	}

}