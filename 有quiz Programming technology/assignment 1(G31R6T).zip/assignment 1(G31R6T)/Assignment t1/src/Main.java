import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

class Plant {
	
	private String name;
	private String type;
	private int nutrients;
	private boolean living;
	private int radiation;

	Plant(String name, String type, int nutrients, boolean living, int radiation) {
		this.name = name;
		this.type = type;
		this.nutrients = nutrients;
		this.living = living;
		this.radiation = radiation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getNutrients() {
		return nutrients;
	}

	public void setNutrients(int nutrients) {
		this.nutrients = nutrients;
	}

	public boolean isLiving() {
		return living;
	}

	public void setLiving(boolean living) {
		this.living = living;
	}

	public int getRadiation() {
		return radiation;
	}

	public void setRadiation(int radiation) {
		this.radiation = radiation;
	}
	
	public void nextDayRadiation() {
		if(!this.isLiving()) {
			return;
		}
		
		//update nutritions according to the left table
		int alpha = 10 - this.getNutrients();
		int delta = this.getNutrients();;
		if (delta < 5) {
			delta += 4;
		} else if (5 <= delta && delta <= 10) {
			delta += 1;
		}
		if (10 < this.getNutrients()) {
			this.setLiving(false);
		}
		
		
		/*
		 * a. alpha, if the need for alpha radiation is 3 or more greater than for the delta radiation
			b. delta, if the need for delta radiation is 3 or more greater than for the alpha radiation
			c. no radiation, otherwise
		 */
		if (alpha == 3 || alpha > delta) {
			this.setRadiation(0);
		} else if (delta == 3 || delta > alpha) {
			this.setRadiation(1);
		} else {
			this.setRadiation(2);
		}
		
		//System.out.println("alpha=" + alpha + " delta=" + delta + " nextRadiation=" + this.getRadiation());
		
	}
	
	public void updateNutrients() {
		
	}
	
	public void print(){
		String radiation;
		if (!this.isLiving()) {
			radiation = "dies";
		} else {
			radiation = "living";
		}
		System.out.println(this.getName() + " " + this.getType() + " "
				+ this.getNutrients() + " " + this.getRadiation());
	}
	
}

class Puffs extends Plant{

	Puffs(String name, String type, int nutrients, boolean living, int radiation) {
		super(name, type, nutrients, living, radiation);
	}

	public void updateNutrients() {
		//System.out.println("name=" + this.getName() + " type=" + this.getType() + " radiation=" + this.getRadiation());
		int[] ParrNutrients = { 2, -2, -1 };
		this.setNutrients(getNutrients()+ParrNutrients[getRadiation()]);
		//System.out.println("updated nutrition=" + this.getNutrients());
	}
	
}

class Deltatree extends Plant{

	Deltatree(String name, String type, int nutrients, boolean living, int radiation) {
		super(name, type, nutrients, living, radiation);
	}

	public void updateNutrients() {
		//System.out.println("name=" + this.getName() + " type=" + this.getType() + " radiation=" + this.getRadiation());
		int[] DarrNutrients = { -3, 4, -1 };
		this.setNutrients(getNutrients()+DarrNutrients[getRadiation()]);
		//System.out.println("updated nutrition=" + this.getNutrients());
	}
	
}

class Parabush extends Plant{

	Parabush(String name, String type, int nutrients, boolean living, int radiation) {
		super(name, type, nutrients, living, radiation);
	}

	public void updateNutrients() {
		//System.out.println("name=" + this.getName() + " type=" + this.getType() + " radiation=" + this.getRadiation());
		int[] BarrNutrients = { 1, 1, -1 };
		this.setNutrients(getNutrients()+BarrNutrients[getRadiation()]);
		//System.out.println("updated nutrition=" + this.getNutrients());
	}
	
}


public class Main {

	public static void main(String[] args) {
		
		ArrayList<String> arrayList = new ArrayList<>();
		//read file
		try {
			FileReader fr = new FileReader("test1");
			BufferedReader bf = new BufferedReader(fr);
			String str;
			// Reads the string by line
			while ((str = bf.readLine()) != null) {
				arrayList.add(str);
			}
			bf.close();
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		int length = arrayList.size();
		int n = Integer.valueOf(arrayList.get(0));
		Plant[] arr = new Plant[n];
		for (int i = 1; i < length - 1; i++) {			
		// split lines into name, type and nutritients
			String[] line = arrayList.get(i).split(" ");
			String name = line[0];
			String type = line[1];
			int nutrients = Integer.valueOf(line[2]);
			boolean living = true;
			int radiation = 2;
			if(type.equals("p")) {
				arr[i-1] = new Puffs(name, type, nutrients, living, radiation);
			}
			else if(type.equals("d")) {
				arr[i-1] = new Deltatree(name, type, nutrients, living, radiation);
			}
			else if(type.equals("b")) {
				arr[i-1] = new Parabush(name, type, nutrients, living, radiation);
			}
			
		}
		
		int day = Integer.valueOf(arrayList.get(length - 1));
		
		// The simulation process
		for (int i = 0; i < day; i++) {
			// Updated nutrient value
			for (int j = 0; j < n; j++) {
				if (arr[j].isLiving() == false)
					continue;
				else {
						arr[j].updateNutrients();
				}

			}
			// Type of radiation for the next day
			for (int j = 0; j < n; j++) {
				arr[j].nextDayRadiation();
			}
			// Print out
			System.out.println("Day " + (i + 1));
			for (int j = 0; j < n; j++) {
				arr[j].print();
			}
		}
		String dies = "";
		String living = "";
		for (int i = 0; i < n; i++) {
			if (arr[i].isLiving() == false) {
				dies += arr[i].getName() + " ";
			} else {
				living += arr[i].getName() + " ";
			}
		}
		System.out.println("----------------");
		System.out.println("dies: ");
		System.out.println(dies);
		System.out.println("----------------");
		System.out.println("living:");
		System.out.println(living);

	}

}