#include <iostream>
#include "coding.h"
#include <vector>
#include <fstream>
#include <stdlib.h>
#include <string>
using namespace std;

vector<ruleT> readrules(string inputfilename)
{
    string tmp,tmp2;
    size_t pos;
    vector<ruleT> rules;
    ruleT rule;
    ifstream file(inputfilename.c_str());
    if(file.is_open()){
        while(!file.eof()){
            getline(file,tmp);
            if(tmp!=""){
                pos=tmp.find(" ");
                tmp2=tmp.substr(0,pos);
                rule.from=tmp2.c_str()[0];

                tmp=tmp.substr(pos+1);
                rule.to=tmp.c_str()[0];

                rules.push_back(rule);
            }
        }

    }else
    {
        cout<<"Error opening the file."<<endl;
    }
    return rules;
}


void readfile(string inputfilename, vector<string> &stringvector)
{
    string tmp;

    ifstream file(inputfilename.c_str());
    if(file.is_open()){
         while(!file.eof()){
            getline(file,tmp);
            if(tmp!=""){
               stringvector.push_back(tmp);
            }
        }

    }

}

void decode(const vector<string> encoded, const vector <ruleT> rules, vector<string> &decoded)
{
    string thestring;
    for(unsigned int i=0;i<encoded.size();i++)
    {
        thestring=encoded.at(i);
        for(unsigned int j=0;j<thestring.length();j++)
      {
           for(unsigned int k=0;k<rules.size();k++)
         {
             char a=rules.at(k).from;
             char b=rules.at(k).to;
            if(thestring[j]==b){
                thestring[j]=a;
            }
         }

      }

      decoded.push_back(thestring);
    }



}

void writefile(string outputfilename, const vector<string> &stringvector)
{
    ofstream file(outputfilename.c_str());
    if(file.is_open()){
        for(unsigned int i=0;i<stringvector.size();i++)
    {
        file<<stringvector.at(i)<<endl;
    }
    }
}
