#include <iostream>
#include "coding.h"
#include <vector>
#include <fstream>

using namespace std;

vector<ruleT> readrules(string inputfilename)
{   vector<ruleT> W;
    string tmp,tmp2;
    int i = 0;
    size_t pos;
    ruleT read;
    ifstream f1(inputfilename.c_str(),ifstream::in);
    if(f1.is_open())
    {
        while(!f1.eof())
        {
            getline(f1,tmp);
            if(tmp!="")
            {
                pos = tmp.find(" ");
                tmp2 = tmp.substr(0,pos);
                read.from = tmp2[0];
                tmp = tmp.substr(pos+1);
                tmp2= tmp.c_str();
                read.to = tmp2[0];
                W.push_back(read);
                i++;
            }
        }f1.close();
    }
    else{ cout << "Error to open the file." << endl;}
    return W;
}
void readfile(string inputfilename, vector<string> &stringvector)
{
    string tmp;
    int i = 0;
    size_t pos;
    ifstream f1(inputfilename.c_str(),ifstream::in);
    if(f1.is_open())
    {
        while(!f1.eof())
        {
            getline(f1,tmp);
            if(tmp!="")
            {

                stringvector.push_back(tmp);
                i++;
            }
        }f1.close();
    }
    else{ cout << "Error to open the file." << endl;}
}
void decode( vector<string> encoded,vector <ruleT> rules, vector<string> &decoded)
{
    for(int i = 0; i < encoded.size(); i++)
    {
        for(int j = 0; j < encoded[i].size();j++)
        {   for(int k = 0; k < rules.size();k++)
        {
            if(encoded[i][j]==rules[k].to)
             {
                    encoded[i][j] = rules[k].from;
                    cout << encoded[i][j];
             }

        }

        }
        decoded.push_back(encoded[i]);

    }
}
void writefile(string outputfilename,  vector<string> &decoded)
{
    ofstream opt(outputfilename.c_str());
    if(opt.is_open())
    {   for(int i = 0; i < decoded.size(); i++)
        {
            opt << decoded[i] << endl;

        }
        opt.close();
    }
}
