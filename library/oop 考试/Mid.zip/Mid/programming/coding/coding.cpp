#include <iostream>
#include "coding.h"
#include <vector>
#include <fstream>
#include <string>
#include <stdlib.h>
using namespace std;

vector<ruleT> readrules(string inputfilename){
    vector<ruleT> V;
    ruleT ee;
    string tmp;
    string tmp2,tmp3;
    size_t pos;
    int i=0;
    ifstream f1(inputfilename.c_str(),ifstream :: in);
    if(f1.is_open()){
            while(!f1.eof()){
        getline(f1,tmp);
        if(tmp!=""){
            pos=tmp.find(" ");
            tmp2=tmp.substr(0,pos);
            //tmp3=tmp.substr(pos+1);
            ee.from=tmp2[0];
            tmp = tmp.substr(pos + 1);

            ee.to=tmp.substr()[0];
            V.push_back(ee);

            i++;
        }
    }f1.close();
    }

    else{cout << "Unable to open the input file" << endl;}
    return V;
}

void readfile(string inputfilename, vector<string> &encoded){
    string s;
    ifstream f2(inputfilename.c_str());
    if(f2.is_open()){
        while(!f2.eof()){
        getline(f2,s);
        encoded.push_back(s);
        }
    }
    else{cout << "Unable to open the input file" << endl;}
    f2.close();

}


void decode( vector<string> &encoded,  vector <ruleT> rules, vector<string> &decoded){

    for(unsigned int i=0;i<encoded.size();i++){
        for(unsigned int j=0;j<encoded[i].size();j++){
            for(unsigned int k=0;k<rules.size();k++){
                if(encoded[i][j]==rules[k].to){
                    encoded[i][j]=rules[k].from;
                }
            }

        }
        decoded.push_back(encoded[i]);
        //cout << encoded[i] << endl;
    }

}
            /*
            if(rules[i].from='k'){
                rules[i].from='r';
            }
            if(rules[i].from=='3'){
                rules[i].from='l';
            }
            if(rules[i].from=='q'){
                rules[i].from='h';
            }

        }
    }

}
*/

void writefile(string outputfilename,vector<string> &decoded){
    ofstream opt(outputfilename.c_str());
    if(opt.is_open()){
        for(unsigned int i=0;i<decoded.size();i++){
        opt << decoded[i] << endl;
        cout << decoded[i] << endl;


        }opt.close();
    }

}


