#include "races.h"
#include <sstream>

//reads in one line from the input file into
//a competition object, returns the competition object
competition readline(ifstream& f) {

}

//writes out one competition object to the console
//for checking purposes
void writecompetition(const competition& c) {
    cout << c.place;
    for (unsigned int i=0;i<c.races.size();i++) {
        cout << " " << c.races[i].km << " " <<
        c.races[i].starters << " " << c.races[i].finishers;
    }
    cout << endl;
}

//returns whether at a competition at least in one of
//the distances more than 90% finished the race
bool morethan90_at_least_once(const competition& c) {

}

//returns a race object, that contains
//how many runners started and finished in all
//distances at a competition
race allrunners(const competition& c) {

}
