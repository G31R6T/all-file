#ifndef RACES_H_INCLUDED
#define RACES_H_INCLUDED

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct race {
    int km;
    int starters;
    int finishers;
};

struct competition {
    string place;
    vector<race> races;
};

//reads in one line from the input file into
//a competition object, returns the competition object
competition readline(ifstream& f);

//writes out one competition object to the console
//for checking purposes
void writecompetition(const competition& c);

//returns whether at a competition at least in one of
//the distances more than 90% finished the race
bool morethan90_at_least_once(const competition& c);

//returns a race object, that contains
//how many runners started and finished in all
//distances at a competition
race allrunners(const competition& c);


#endif // RACES_H_INCLUDED
