package com.cdxmq3.luosiwei.task1;

import com.cdxmq3.luosiwei.task1.boardimpl.Property;

import java.util.List;
import java.util.Queue;
import java.util.Scanner;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/9/27 11:20 上午
 **/
public class RunGame {
    public static void main(String[] args) {
        CyclicalBoard cyclicalBoard = new CyclicalBoard();
        List<Fields> fields = cyclicalBoard.getFields();
        List<Player> players = cyclicalBoard.getPlayers();
        Queue<Integer> rolldices = cyclicalBoard.getRolldices();
        int round = 0;
        System.out.println("Please input the round:");
        Scanner scanner = new Scanner(System.in);
        int wantedRound = scanner.nextInt();
        while(round != wantedRound) {
            for (Player player : players) {
                if(!player.isDead()) {
                    int roll = rolldices.poll();
                    player.setPosition((player.getPosition() + roll) % fields.size());
                    player.strategies(fields.get(player.getPosition()));
                    //System.out.println(player.getName() + " " + player.getTotalMoney() + " " + player.getPosition() + " " + (player.isDead() ? "DEAD" : "ALIVE"));
                }
            }
            round++;
        }

        for (Player player : players) {
            String res = player.getName() + " - " + "Total Money: " + player.getTotalMoney() + " Owned Property: [ ";
            for (Property ownedProperty : player.getOwnedProperties()) {
                res += ownedProperty.getName() + " ";
            }
            res += "] ";
            System.out.println(res);
        }
        
    }
}
