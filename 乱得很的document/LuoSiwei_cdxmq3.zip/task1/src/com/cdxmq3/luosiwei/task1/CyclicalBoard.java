package com.cdxmq3.luosiwei.task1;

import com.cdxmq3.luosiwei.task1.boardimpl.LuckyField;
import com.cdxmq3.luosiwei.task1.boardimpl.Property;
import com.cdxmq3.luosiwei.task1.boardimpl.Service;
import com.cdxmq3.luosiwei.task1.exceptions.InvalidInputException;
import com.cdxmq3.luosiwei.task1.playerimpl.CarefulPlayer;
import com.cdxmq3.luosiwei.task1.playerimpl.GreedyPlayer;
import com.cdxmq3.luosiwei.task1.playerimpl.TacticalPlayer;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/9/27 11:14 上午
 **/
public class CyclicalBoard {
    /**
     * The List of field, read from file.
     */
    private List<Fields> fields;
    /**
     * The List of player, read from file
     */
    private List<Player> players;
    /**
     * The Queue of roll dice, read from file
     */
    private final Queue<Integer> rolldices;
    /**
     * board Init Router
     */
    private String boardInitRouter = "src/com/cdxmq3/luosiwei/task1/files/board_init.txt";
    /**
     * player Init Router
     */
    private String playerInitRouter = "src/com/cdxmq3/luosiwei/task1/files/player_init.txt";
    /**
     * roll dices Init Router
     */
    private String rollDicesInitRouter = "src/com/cdxmq3/luosiwei/task1/files/roll_dices_init.txt";
    /**
     * The scanner of Files
     */
    private Scanner boardInitScanner;
    private Scanner playerInitScanner;
    private Scanner rollDicesInitScanner;

    /**
     * The Constructor of CyclicalBoard
     */
    public CyclicalBoard() {
        try {
            boardInitScanner = new Scanner(new FileReader(boardInitRouter));
            playerInitScanner = new Scanner(new FileReader(playerInitRouter));
            rollDicesInitScanner = new Scanner(new FileReader(rollDicesInitRouter));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            this.fields = initFields();
            this.players = initPlayers();
        } catch (InvalidInputException e) {
            e.printStackTrace();
        }
        this.rolldices = initRollDices();
    }

    public CyclicalBoard(String boardInitRouter, String playerInitRouter, String rollDicesInitRouter) {
        this.boardInitRouter = boardInitRouter;
        this.playerInitRouter = playerInitRouter;
        this.rollDicesInitRouter = rollDicesInitRouter;
        try {
            boardInitScanner = new Scanner(new FileReader(boardInitRouter));
            playerInitScanner = new Scanner(new FileReader(playerInitRouter));
            rollDicesInitScanner = new Scanner(new FileReader(rollDicesInitRouter));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            this.fields = initFields();
            this.players = initPlayers();
        } catch (InvalidInputException e) {
            e.printStackTrace();
        }
        this.rolldices = initRollDices();
    }

    /**
     * The Init of Fields
     * @return
     * @throws InvalidInputException
     */
    private List<Fields> initFields() throws InvalidInputException {
        try {
            int numOfFields = boardInitScanner.nextInt();
        }catch (Exception e){
            System.out.println("Empty File!");
        }
        List<Fields> fieldList = new ArrayList<>();
        while(boardInitScanner.hasNext()) {
            String type = boardInitScanner.next();
            Fields field = null;
            int cost = 0;
            switch (type) {
                case "Property":
                    String name = boardInitScanner.next();
                    field = new Property(name);
                    break;
                case "Service":
                    cost = boardInitScanner.nextInt();
                    field = new Service(cost);
                    break;
                case "LuckyField":
                    cost = boardInitScanner.nextInt();
                    field = new LuckyField(cost);
                    break;
                default:
                    throw new InvalidInputException();
            }
            fieldList.add(field);
        }
        return fieldList;
    }

    /**
     * The init of players
     * @return
     * @throws InvalidInputException
     */
    private List<Player> initPlayers() throws InvalidInputException {
        try{
            int numOfPlayers = playerInitScanner.nextInt();
        }catch (Exception e){
            System.out.println("Empty File!");
        }
        List<Player> playerList = new ArrayList<>();
        while(playerInitScanner.hasNext()){
            Player player = null;
            String name = playerInitScanner.next();
            String strategies = playerInitScanner.next();
            switch (strategies) {
                case "GreedyPlayer":
                    player = new GreedyPlayer(name);
                    break;
                case "CarefulPlayer":
                    player = new CarefulPlayer(name);
                    break;
                case "TacticalPlayer":
                    player = new TacticalPlayer(name);
                    break;
                default:
                    throw new InvalidInputException();
            }
            playerList.add(player);
        }
        return playerList;
    }

    /**
     * The init of roll dices
     * @return
     */
    private Queue<Integer> initRollDices(){
        Queue<Integer> rollDiceQueue = new LinkedList<>();
        while(rollDicesInitScanner.hasNext()) {
            rollDiceQueue.add(rollDicesInitScanner.nextInt());
        }
        return rollDiceQueue;
    }

    public List<Fields> getFields() {
        return fields;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public Queue<Integer> getRolldices() {
        return rolldices;
    }

}
