package com.cdxmq3.luosiwei.task1.playerimpl;

import com.cdxmq3.luosiwei.task1.Fields;
import com.cdxmq3.luosiwei.task1.Player;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/10/4 7:12 下午
 **/
public class TacticalPlayer extends Player {
    /**
     * Tactical Player's time, for skips each second chance
     */
    private int time;

    /**
     * The Constructor of Tactical Player
     * @param name
     */
    public TacticalPlayer(String name) {
        super(name);
        this.time = 1;
    }

    /**
     * The strategy of Tactical Player
     * he skips each second chance when he could buy.
     * @param field
     */
    @Override
    public void strategies(Fields field) {
        if(field.getFieldName().equals("Property")) {
            if(!field.isOwned()){
                if(time%2!=0){
                    field.changeMoney(this);
                }
                time++;
            }else{
                field.changeMoney(this);
            }
        }else{
            field.changeMoney(this);
        }
    }
}
