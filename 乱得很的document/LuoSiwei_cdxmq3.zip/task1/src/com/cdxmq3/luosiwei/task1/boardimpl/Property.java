package com.cdxmq3.luosiwei.task1.boardimpl;

import com.cdxmq3.luosiwei.task1.Fields;
import com.cdxmq3.luosiwei.task1.Player;

import java.util.ArrayList;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/9/27 11:14 上午
 **/
public class Property implements Fields {
    /**
     * The name of Property
     */
    private String name;

    /**
     * The Ownner of Property
     */
    private Player ownner;

    /**
     * Is built a house in this place
     */
    private boolean housed;

    /**
     * The Constructor of Property
     * @param name
     */
    public Property(String name) {
        this.name = name;
        this.ownner = null;
        this.housed = false;
    }

    /**
     * return the money if we need to buy the Property
     * @return
     */
    private int ownProperty(){
        return -1000;
    }

    /**
     * return the money if we need to build the house here
     * @return
     */
    private int buildHouse(){
        return -4000;
    }

    @Override
    public String getFieldName() {
        return "Property";
    }

    public String getName() {
        return name;
    }

    /**
     * After the money calls this method, the total amount of the player will be calculated.
     * @param player
     */
    @Override
    public void changeMoney(Player player) {
        if( ownner != null && ownner.isDead() ){
            ownner = null;
        }
        if( ownner == null && player.getTotalMoney() >= ownProperty() ){
            ownner = player;
            player.getOwnedProperties().add(this);
            player.setTotalMoney(player.getTotalMoney()+ownProperty());
        }else if( ownner == player && !housed && player.getTotalMoney() >= buildHouse()){
            housed = true;
            player.setTotalMoney(player.getTotalMoney()+buildHouse());
        }else if( ownner != player && !housed ){
            ownner.setTotalMoney(ownner.getTotalMoney()+500);
            player.setTotalMoney(player.getTotalMoney()-500);
        }else if( ownner != player && housed ){
            ownner.setTotalMoney(ownner.getTotalMoney()+2000);
            player.setTotalMoney(player.getTotalMoney()-2000);
        }
        if(player.getTotalMoney() <= 0) {
            player.setDead(true);
            player.setTotalMoney(0);
            player.setOwnedProperties(new ArrayList<>());
        }
    }

    /**
     * Is someone owned the Field.
     * @return
     */
    @Override
    public boolean isOwned() {
        return ownner!=null;
    }

    public Player getOwnner() {
        return ownner;
    }

    /**
     * Is someone built the house in the Field.
     * @return
     */
    public boolean isHoused() {
        return housed;
    }
}
