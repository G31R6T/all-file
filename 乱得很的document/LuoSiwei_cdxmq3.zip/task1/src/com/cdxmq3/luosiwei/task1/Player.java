package com.cdxmq3.luosiwei.task1;

import com.cdxmq3.luosiwei.task1.boardimpl.Property;

import java.util.ArrayList;
import java.util.List;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/10/4 5:50 下午
 **/
public abstract class Player {
    /**
     * the player's name
     */
    private String name;

    /**
     * the player's total money
     */
    private int totalMoney;

    /**
     * the player's position in the board
     */
    private int position;

    /**
     * the owned properties of player
     */
    private List<Property> ownedProperties;

    /**
     * player's status : Dead | Alive
     */
    private boolean isDead;

    public List<Property> getOwnedProperties() {
        return ownedProperties;
    }

    public void setOwnedProperties(List<Property> ownedProperties) {
        this.ownedProperties = ownedProperties;
    }

    /**
     * The Constructor of Player
     * @param name
     */
    public Player(String name) {
        this.name = name;
        this.totalMoney = 10000;
        this.position = 0;
        this.ownedProperties = new ArrayList<>();
        this.isDead = false;
    }

    /**
     * the abstract method strategies, which player can do their different stratege.
     * @param field
     */
    public abstract void strategies(Fields field);

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(int totalMoney) {
        this.totalMoney = totalMoney;
    }

    public boolean isDead() {
        return isDead;
    }

    public void setDead(boolean dead) {
        isDead = dead;
    }
}
