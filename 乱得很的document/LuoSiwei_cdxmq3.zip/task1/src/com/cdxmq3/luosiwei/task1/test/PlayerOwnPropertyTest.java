package com.cdxmq3.luosiwei.task1.test;

import com.cdxmq3.luosiwei.task1.CyclicalBoard;
import com.cdxmq3.luosiwei.task1.Fields;
import com.cdxmq3.luosiwei.task1.Player;
import com.cdxmq3.luosiwei.task1.RunGame;
import com.cdxmq3.luosiwei.task1.exceptions.InvalidInputException;
import org.junit.Test;

import java.util.List;
import java.util.Queue;
import java.util.Scanner;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/10/4 8:58 下午
 **/

public class PlayerOwnPropertyTest extends BaseTest{
    /**
     * test the first test case,
     * the player output correct or no AND
     * get the player's totalmoney correct or no
     */
    @Test
    public void testCaseFileOnePlayerTest(){
        try {
            super.base(1,1);
        } catch (InvalidInputException e) {
            e.printStackTrace();
        }
        List<Player> players = super.players;
        assert(players.get(2).getName().equals("Doraemon"));
        assert(players.get(2).getTotalMoney() == 9000);
    }

    /**
     * test the first test case
     * Check if the player dead or no
     */
    @Test
    public void testCaseFileOnePlayerAliveTest(){
        try {
            super.base(1,1);
        } catch (InvalidInputException e) {
            e.printStackTrace();
        }
        List<Player> players = super.players;
        assert(!players.get(1).isDead());
    }
}
