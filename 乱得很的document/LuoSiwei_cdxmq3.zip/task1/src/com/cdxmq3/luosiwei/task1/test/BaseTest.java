package com.cdxmq3.luosiwei.task1.test;

import com.cdxmq3.luosiwei.task1.CyclicalBoard;
import com.cdxmq3.luosiwei.task1.Fields;
import com.cdxmq3.luosiwei.task1.Player;
import com.cdxmq3.luosiwei.task1.exceptions.InvalidInputException;

import java.util.List;
import java.util.Queue;
import java.util.Scanner;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/10/4 9:47 下午
 **/
public class BaseTest {
    private CyclicalBoard cyclicalBoard;
    public List<Fields> fields;
    public List<Player> players;
    public Queue<Integer> rolldices;
    public void base(int num,int wantedRound) throws InvalidInputException {
        if(num == 1) {
            cyclicalBoard = new CyclicalBoard("src/com/cdxmq3/luosiwei/task1/test/testcasefiles/1/board_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/1/player_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/1/roll_dices_init.txt");
        }else if(num == 2){
            cyclicalBoard = new CyclicalBoard("src/com/cdxmq3/luosiwei/task1/test/testcasefiles/2/board_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/2/player_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/2/roll_dices_init.txt");
        }else if(num == 3){
            cyclicalBoard = new CyclicalBoard("src/com/cdxmq3/luosiwei/task1/test/testcasefiles/3/board_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/3/player_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/3/roll_dices_init.txt");
        }else if(num == 4){
            cyclicalBoard = new CyclicalBoard("src/com/cdxmq3/luosiwei/task1/test/testcasefiles/4/board_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/4/player_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/4/roll_dices_init.txt");
        }else if(num == 5){
            cyclicalBoard = new CyclicalBoard("src/com/cdxmq3/luosiwei/task1/test/testcasefiles/5/board_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/5/player_init.txt",
                    "src/com/cdxmq3/luosiwei/task1/test/testcasefiles/5/roll_dices_init.txt");
        }else{
            throw new InvalidInputException();
        }
        this.fields = cyclicalBoard.getFields();
        this.players = cyclicalBoard.getPlayers();
        this.rolldices = cyclicalBoard.getRolldices();
        int round = 0;
        while(round != wantedRound) {
            for (Player player : players) {
                if(!player.isDead()) {
                    int roll = rolldices.poll();
                    player.setPosition((player.getPosition() + roll) % fields.size());
                    player.strategies(fields.get(player.getPosition()));
                }
            }
            round++;
        }
    }
}
