package com.cdxmq3.luosiwei.task1.test;

import com.cdxmq3.luosiwei.task1.Fields;
import com.cdxmq3.luosiwei.task1.exceptions.InvalidInputException;
import org.junit.Test;

import java.util.List;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/9/27 11:20 上午
 **/
public class GameProcessTest extends BaseTest {
    /**
     * Test the file exist or not
     */
    @Test
    public void fileExistTest(){
        try {
            super.base(2,1);
        } catch (InvalidInputException e) {
            e.printStackTrace();
        }
        assert(super.fields.isEmpty());
    }

    /**
     * Test the file exist or not
     */
    @Test
    public void fileExistTest2(){
        try {
            super.base(1,1);
        } catch (InvalidInputException e) {
            e.printStackTrace();
        }
        assert(!super.fields.isEmpty());
    }

    /**
     * Test roll dices input if correct or not
     */
    @Test
    public void rollDicesInputTest(){
        try {
            super.base(1,1);
        } catch (InvalidInputException e) {
            e.printStackTrace();
        }
        assert(super.rolldices.peek()==2);
    }
}
