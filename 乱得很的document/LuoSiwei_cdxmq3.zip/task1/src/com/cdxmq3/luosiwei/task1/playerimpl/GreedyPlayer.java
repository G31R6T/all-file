package com.cdxmq3.luosiwei.task1.playerimpl;

import com.cdxmq3.luosiwei.task1.Fields;
import com.cdxmq3.luosiwei.task1.Player;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/10/4 7:11 下午
 **/
public class GreedyPlayer extends Player {

    /**
     * The Constructor of Greedy Player
     * @param name
     */
    public GreedyPlayer(String name) {
        super(name);
    }

    /**
     * The strategy of Greedy Player
     * If he steps on an unowned property, or his own property without a house,
     * he starts buying it, if he has enough money for it.
     * @param field
     */
    @Override
    public void strategies(Fields field) {
        field.changeMoney(this);
    }
}
