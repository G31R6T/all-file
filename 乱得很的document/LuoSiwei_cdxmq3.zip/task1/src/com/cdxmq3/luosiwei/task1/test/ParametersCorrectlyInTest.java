package com.cdxmq3.luosiwei.task1.test;

import org.junit.Test;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/10/4 8:57 下午
 **/
public class ParametersCorrectlyInTest extends BaseTest {
    /**
     * an empty test, import junit framework
     */
    @Test
    public void test(){

    }
}
