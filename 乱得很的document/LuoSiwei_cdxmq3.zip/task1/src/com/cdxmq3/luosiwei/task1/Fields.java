package com.cdxmq3.luosiwei.task1;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/9/27 11:30 上午
 **/
public interface Fields {
    /**
     * get field's name
     * @return
     */
    String getFieldName();

    /**
     * After the money calls this method, the total amount of the player will be calculated.
     * @param player
     */
    void changeMoney(Player player);

    /**
     * Is someone owned the Field.
     * @return
     */
    boolean isOwned();
}
