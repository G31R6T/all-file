package com.cdxmq3.luosiwei.task1.playerimpl;

import com.cdxmq3.luosiwei.task1.Fields;
import com.cdxmq3.luosiwei.task1.Player;
import com.cdxmq3.luosiwei.task1.boardimpl.Property;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/10/4 7:11 下午
 **/
public class CarefulPlayer extends Player {

    /**
     * The Constructor of CarefulPlayer
     * @param name
     */
    public CarefulPlayer(String name) {
        super(name);
    }

    /**
     * The strategy of Careful Player
     * he buys in a round only for at most half the amount of his money.
     * @param field
     */
    @Override
    public void strategies(Fields field) {
        if(field.getFieldName().equals("Property")) {
            Property property = (Property) field;
            if(!field.isOwned()){
                if(property.isHoused()){
                    if(this.getTotalMoney()/2 >= 4000){
                        field.changeMoney(this);
                    }
                }else{
                    if(this.getTotalMoney()/2 >= 1000){
                        field.changeMoney(this);
                    }
                }
            }else{
                field.changeMoney(this);
            }
        }else{
            field.changeMoney(this);
        }
    }
}
