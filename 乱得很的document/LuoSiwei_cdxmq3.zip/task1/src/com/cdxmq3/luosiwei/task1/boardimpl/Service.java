package com.cdxmq3.luosiwei.task1.boardimpl;

import com.cdxmq3.luosiwei.task1.Fields;
import com.cdxmq3.luosiwei.task1.Player;

import java.util.ArrayList;

/**
 * @描叙:
 * @作者: mzdora
 * @邮箱: mzdora@qq.com
 * @创建时间: 2021/9/27 11:14 上午
 **/
public class Service implements Fields {
    /**
     * The cost of Service
     */
    private int cost;

    /**
     * The Constructor of Service
     * @param cost
     */
    public Service(int cost) {
        this.cost = cost;
    }

    @Override
    public String getFieldName() {
        return "Service";
    }

    /**
     * After the money calls this method, the total amount of the player will be calculated.
     * @param player
     */
    @Override
    public void changeMoney(Player player) {
        player.setTotalMoney(player.getTotalMoney()-cost);
        if(player.getTotalMoney() <= 0) {
            player.setDead(true);
            player.setTotalMoney(0);
            player.setOwnedProperties(new ArrayList<>());
        }
    }

    /**
     * Is someone owned the Field.
     * @return
     */
    @Override
    public boolean isOwned() {
        return false;
    }
}
