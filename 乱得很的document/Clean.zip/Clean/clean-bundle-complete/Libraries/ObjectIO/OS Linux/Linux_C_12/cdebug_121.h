#include "util_121.h"
#include "clean_types.h"

extern int Rand (void);
extern OS ConsolePrint (CLEAN_STRING,OS);
