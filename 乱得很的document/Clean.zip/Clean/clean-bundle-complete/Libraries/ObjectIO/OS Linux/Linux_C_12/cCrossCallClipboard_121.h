#include "util_121.h"

//	InstallCrossCallClipboard adds the proper cross call procedures to the
//	cross call procedures managed by cCrossCall_13.c.
extern OS InstallCrossCallClipboard (OS);
