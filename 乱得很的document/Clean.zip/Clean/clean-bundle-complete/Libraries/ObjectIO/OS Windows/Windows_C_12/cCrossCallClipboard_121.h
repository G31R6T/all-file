#include <windows.h>


//	InstallCrossCallClipboard adds the proper cross call procedures to the
//	cross call procedures managed by cCrossCall_13.c.
extern int InstallCrossCallClipboard (int ios);
