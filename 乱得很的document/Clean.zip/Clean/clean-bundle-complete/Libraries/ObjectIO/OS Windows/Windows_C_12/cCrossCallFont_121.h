#include <windows.h>


//	InstallCrossCallFont adds the proper cross call procedures to the
//	cross call procedures managed by cCrossCall_121.c.
extern int InstallCrossCallFont (int ios);
