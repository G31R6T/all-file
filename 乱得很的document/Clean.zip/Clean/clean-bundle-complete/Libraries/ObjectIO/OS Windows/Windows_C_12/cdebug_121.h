#include "util_121.h"

extern int Rand (void);
extern OS ConsolePrint (CLEAN_STRING,OS);
