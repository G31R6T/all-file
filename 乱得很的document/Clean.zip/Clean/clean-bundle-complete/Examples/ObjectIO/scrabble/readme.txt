To create an application of the scrabble example program you should
- set a path to either the Windows95 or the Macintosh folder (depending 
  on which system you have)
- set a path to either the English or the Nederlands folder (depending
  on whch language you prefer)
- set the heap size for this application to 2M and the stack size to 500K.
  (in the CleanIDE's Application Options dialogue)
